Wilcox <- function(x, Y ) {
  x <- as.matrix(x)
  test <- apply(x, 2, function(x) wilcox.exact(x[Y==1], x[Y==0]))
  test.pvalue <- sapply(test, function(x) x$p.value)
  adjust.pvalue <- p.adjust(test.pvalue, "BH")
  return(list(test.pvalue = test.pvalue, adjust.pvalue = adjust.pvalue))  
}
