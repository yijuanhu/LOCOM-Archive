# ----------------------------
# Binary Trait and Binary Confounder Setting Simulation
# ----------------------------
library(psych)
library(dirmult) # simPop
library(Rcpp)
library(RcppArmadillo)
library(R.utils) 
library(metap)
library(psych)
library(vegan)
library(ANCOMBC)
library(phyloseq)
library(ALDEx2)
source("utils.R")
source("Method_Comparison_Confounder.R")
source("wilcox.R")
source("ancom_v2.1.R")

test.global <- 1    # test global hypothesis or not?
test.otu <- 1       # test individual otus or not?
causal.type <- 1    # simulation scenario
library.mu <- 10000 # mean of library size
disp <- 0.02        # dispersion parameter
n.sam <- 100        # total sample size
alpha <- 3          # effect size 
gamma <- 2          # confounder effect size
freq.thres <- 0     # frequency threshold
censor.thres <- 0.8 # presence/absence threshold
ss <- 3             
library.sd = library.mu/ss # standard error in library size 
lib.sizer.lower = 2000     # lower bound for library size
fdr.target <- 0.2 # nominal fdr value

n.sim <- 1
for (i.seed in 1:n.sim) {
  cat("i.seed",i.seed,"\n")
  
  # ----------------------------
  # Set frequency value
  # ----------------------------
  pi <- read.table("input_throat/fit_dirmult_pi.txt", header=FALSE, as.is=TRUE)[,1]
  n.otus = length(pi)
  
  if(causal.type == 1){
	spike.col.only <- which(pi >= 0.002)[1:10]
	confounder.col.only <- which(pi >= 0.002)[21:30]
	spike.confounder.both <- which(pi >= 0.002)[11:20]
  } 
  
  if(causal.type == 2){
  	spike.col.only <- order(pi, decreasing = TRUE)[1:3]
	  confounder.col.only <- order(pi, decreasing = TRUE)[31:33]
	  spike.confounder.both <- order(pi, decreasing = TRUE)[4:5]
  }
  
  causal.otus.sim = c(spike.col.only, spike.confounder.both)
  n.otus.causal.sim = length(causal.otus.sim)
  non.causal.otus.sim = setdiff(1:n.otus, causal.otus.sim)
  n.otus.noncausal.sim = length(non.causal.otus.sim)

  # -----------------------------
  # Simulate Data
  # -----------------------------
  simData <- SimulateData(otu.freq = pi, 
                          spike.col.only = spike.col.only, 
                          confounder.col.only = confounder.col.only, 
                          spike.confounder.both = spike.confounder.both, 
                          alpha = alpha, 
                          gamma = gamma, 
                          library.mu = library.mu, 
                          library.sd = library.sd, 
                          lib.sizer.lower = lib.sizer.lower, 
                          disp = disp, 
                          n.sam = n.sam, 
                          trait = "BinBin",
                          frac = 0.5, 
                          rho = 0.2, 
                          causal.type = causal.type,
                          seed = i.seed)
  
  otu.table.sim <- simData$otu.table.sim
  freq.table.sim <- simData$freq.table.sim
  Y <- simData$Y
  C <- simData$C
  
  # -----------------------------
  # Filter Data
  # -----------------------------
  filterData <- filterOTU(otu.table = otu.table.sim, freq.table = freq.table.sim, refer.col = 468, censor.thres = censor.thres, freq.thres = freq.thres, eps = 1)
  otu.table.sim.filter <-filterData$otu.table.filter
  refer.col <- filterData$refer.col
  otuname <- filterData$otuname
  filter.idx <- filterData$filter.idx
  censoring.rate <- filterData$censoring.rate
  causal.otus.sim.filter <- causal.otus.sim[!causal.otus.sim %in% filter.idx]
  non.causal.otus.sim.filter <- non.causal.otus.sim[!non.causal.otus.sim %in% filter.idx]
  cat("number of causal otu:", length(causal.otus.sim.filter), "\n") 
  
  # -----------------------------
  # Global Test
  # -----------------------------
  if(test.global == 1){
    ps.count <- 0.5
    otu.table.sim.filter.ps <- otu.table.sim.filter + ps.count
    otu.table.sim.filter.clr <-  log(otu.table.sim.filter.ps) - apply(otu.table.sim.filter.ps, 1, function(x) mean(log(x)))
    set.seed(0)
    design <- data.frame(Y = Y, C = C)
    otu.dist<-vegdist(otu.table.sim.filter.clr, method='euclidean')
    res <- adonis2(otu.dist ~ C + Y, data= design, permutations = 9999, method="euclidean")
    pvalue1 <- res$`Pr(>F)`[2]
    
	
	  ps.count <- 1
	  otu.table.sim.filter.ps <- otu.table.sim.filter + ps.count
	  otu.table.sim.filter.clr <-  log(otu.table.sim.filter.ps) - apply(otu.table.sim.filter.ps, 1, function(x) mean(log(x)))
    set.seed(0)
    design <- data.frame(Y = Y, C = C)
    otu.dist<-vegdist(otu.table.sim.filter.clr, method='euclidean')
    res <- adonis2(otu.dist ~ C + Y, data= design, permutations = 9999, method="euclidean")
    pvalue2 <- res$`Pr(>F)`[2]
	
    global.pvalue <- c(pvalue1, pvalue2)
  }
  
  # -----------------------------
  # OTU Test 
  # -----------------------------
  n.otus.causal.sim.filter <- length(causal.otus.sim.filter)
  n.otus.noncausal.sim.filter <- length(non.causal.otus.sim)
  if(test.otu == 1){
    res.aldex2 <- Method_Comparsion_Confounder(otu.table = otu.table.sim.filter, otu.table.sim = otu.table.sim, 
                                               filter.idx = filter.idx, Y = Y, C = C, C.name = "C", fdr.target = fdr.target, method = "ALDEx2", 
                                               causal.otus.sim = causal.otus.sim.filter, 
                                               n.otus.causal.sim = n.otus.causal.sim.filter, 
                                               non.causal.otus.sim = non.causal.otus.sim.filter, 
                                               n.otus.noncausal.sim = n.otus.noncausal.sim.filter)
    res.ancom <- Method_Comparsion_Confounder(otu.table = otu.table.sim.filter, otu.table.sim = otu.table.sim, 
                                              filter.idx = filter.idx, Y = Y, C = C, C.name = "C", fdr.target = fdr.target, method = "ANCOM", 
                                              causal.otus.sim = causal.otus.sim.filter, 
                                              n.otus.causal.sim = n.otus.causal.sim.filter, 
                                              non.causal.otus.sim = non.causal.otus.sim.filter, 
                                              n.otus.noncausal.sim = n.otus.noncausal.sim.filter, filter = "LOCOM")
	  res.ancom2 <- Method_Comparsion_Confounder(otu.table = otu.table.sim.filter, otu.table.sim = otu.table.sim, 
	                                             filter.idx = filter.idx, Y = Y, C = C, C.name = "C", fdr.target = fdr.target, method = "ANCOM", 
                                               causal.otus.sim = causal.otus.sim.filter, 
                                               n.otus.causal.sim = n.otus.causal.sim.filter, 
                                               non.causal.otus.sim = non.causal.otus.sim.filter, 
                                               n.otus.noncausal.sim = n.otus.noncausal.sim.filter, filter = "ANCOM")
	  res.ancombc <- Method_Comparsion_Confounder(otu.table = otu.table.sim.filter, otu.table.sim = otu.table.sim, 
	                                              filter.idx = filter.idx, Y = Y, C = C, C.name = "C", fdr.target = fdr.target, method = "ANCOMBC", 
                                                causal.otus.sim = causal.otus.sim.filter, 
	                                              n.otus.causal.sim = n.otus.causal.sim.filter, 
	                                              non.causal.otus.sim = non.causal.otus.sim.filter,
	                                              n.otus.noncausal.sim = n.otus.noncausal.sim.filter, filter = "LOCOM")
	  res.ancombc2 <- Method_Comparsion_Confounder(otu.table = otu.table.sim.filter, otu.table.sim = otu.table.sim, 
	                                               filter.idx = filter.idx, Y = Y, C = C, C.name = "C", fdr.target = fdr.target, method = "ANCOMBC", 
                                                 causal.otus.sim = causal.otus.sim.filter, 
	                                               n.otus.causal.sim = n.otus.causal.sim.filter, 
	                                               non.causal.otus.sim = non.causal.otus.sim.filter, 
	                                               n.otus.noncausal.sim = n.otus.noncausal.sim.filter, filter = "ANCOM")
											  
    mat <- rbind(unlist(res.ancom),
  			          unlist(res.ancom2),
  				        unlist(res.ancombc),
  				        unlist(res.ancombc2),
  				        unlist(res.aldex2))
    
  }
}
