# -------------------------
# This script is used to compare six different methods: ANCOM; ALDEx2; WRENCH; DACOMP; Wilcox-PS; Wilcox  
# -------------------------
library(ALDEx2)
library(Wrench)
library(dacomp)
library(exactRankTests)

Method_Comparsion_NoConfounder <- function(otu.table, otu.table.sim, filter.idx,  Y, fdr.target, method, 
                                           causal.otus.sim, n.otus.causal.sim, non.causal.otus.sim, n.otus.noncausal.sim, 
                                           perc = 0.9, median.SD.threshold = 1.3, filter = "ANCOM", ps.count = 1){
      # Args: otu.table: filtered otu.table
	    #       otu.table.sim: original otu.table
      #       filter.idx: filter index
      #       Y: trait
      #       fdr.tagert: fdr.target name
      #       method: method name		
      #       perc: parameter for ANCOM
      #       meidan.SD.threshold: parameter for DACOMP
      #       filter: filtering criterion, "ANCOM": default criterion in ANCOM	
      #       ps.count: pseudo count number
  
    # ------------------
    # ANCOMBC
    # ------------------
  	if(method == "ANCOMBC"){
  		#================Build a Phyloseq-Class Object from Scratch==================
  		otu.mat <- t(otu.table.sim)
  		rownames(otu.mat) = 1:nrow(otu.mat)
  		colnames(otu.mat) = paste0("sample", 1:ncol(otu.mat))
  		
  		meta <- data.frame(group = Y,
  						   row.names = paste0("sample", 1:ncol(otu.mat)),
  						   stringsAsFactors = FALSE)
  		
  		tax.mat = matrix(sample(letters, 7 * nrow(otu.mat), replace = TRUE),
  						 nrow = nrow(otu.mat), ncol = 7)
  		rownames(tax.mat) = rownames(otu.mat)
  		colnames(tax.mat) = c("Kingdom", "Phylum", "Class", "Order",
  							  "Family", "Genus", "Species")
  		OTU = otu_table(otu.mat, taxa_are_rows = TRUE)
  		META = sample_data(meta)
  		TAX = tax_table(tax.mat)
  		physeq = phyloseq(OTU, META, TAX)
  		#========================Run ANCOMBC Using a Real Data=======================
  		if(filter == "LOCOM"){
    		out = ancombc(phyloseq = physeq, formula = "group",
    					  p_adj_method = "holm", zero_cut = 0.80, lib_cut = 1000,
    					  group = "group", struc_zero = TRUE, neg_lb = FALSE,
    					  tol = 1e-5, max_iter = 100, conserve = TRUE,
    					  alpha = 0.05, global = TRUE)
  		} else {
  		  out = ancombc(phyloseq = physeq, formula = "group",
  		                p_adj_method = "holm", zero_cut = 0.90, lib_cut = 1000,
  		                group = "group", struc_zero = TRUE, neg_lb = FALSE,
  		                tol = 1e-5, max_iter = 100, conserve = TRUE,
  		                alpha = 0.05, global = TRUE)
  		  
  		}
  		
  		otu.ancom = as.numeric(rownames(out$res$q_val)[which(out$res$q_val < fdr.target)])
  		(n.otu.ancom = length(otu.ancom))
  		(sen.ancom = sum(otu.ancom %in% causal.otus.sim)/n.otus.causal.sim)
  		(sep.ancom = 1- sum(otu.ancom %in% non.causal.otus.sim)/n.otus.noncausal.sim)
  		(FDR.ancom = (n.otu.ancom - sum(otu.ancom %in% causal.otus.sim))/n.otu.ancom)
  		
  		n.otu <- n.otu.ancom
  		sen <- sen.ancom
  		sep <- sep.ancom	
  		FDR <- FDR.ancom
	  }  
  
	  if(method == "ANCOM"){
  		otu.table.sim.ancom <- t(otu.table.sim)
  		colnames(otu.table.sim.ancom) <- paste("ID", c(1:ncol(otu.table.sim.ancom)), sep = "")
  		
  		meta_data <- data.frame(Sample.ID = paste("ID", c(1:ncol(otu.table.sim.ancom)), sep = ""), Y = Y)   
  		feature_table = otu.table.sim.ancom; sample_var = "Sample.ID"; group_var = NULL
  		out_cut = 0.05; lib_cut = 1000; neg_lb = FALSE
  		if(filter == "LOCOM"){
  		  zero_cut = 0.80; 
  		} else {
  		  zero_cut = 0.90; 
  		}
  		prepro = feature_table_pre_process(feature_table, meta_data, sample_var, group_var, out_cut, zero_cut, lib_cut, neg_lb)
  		feature_table = prepro$feature_table 
  		meta_data = prepro$meta_data # Preprocessed metadata
  		struc_zero = prepro$structure_zeros # Structural zero info
  		
  		main_var = "Y"; p_adj_method = "BH";
  		adj_formula = NULL; rand_formula = NULL
  		res.ancom = ANCOM(feature_table, meta_data, struc_zero, main_var, p_adj_method, fdr.target, adj_formula, rand_formula)
  		
  		otu.ancom = as.numeric(as.character(res.ancom$out$taxa_id[which(res.ancom$out[, paste("detected_", perc, sep = "")]== TRUE)])) # choose 0.9 percentile as cutoff
  		(n.otu.ancom = length(otu.ancom))
  		(sen.ancom = sum(otu.ancom %in% causal.otus.sim)/n.otus.causal.sim)
  		(sep.ancom = 1- sum(otu.ancom %in% non.causal.otus.sim)/n.otus.noncausal.sim)
  		(FDR.ancom = (n.otu.ancom - sum(otu.ancom %in% causal.otus.sim))/n.otu.ancom)
  		
  		n.otu <- n.otu.ancom
  		sen <- sen.ancom
  		sep <- sep.ancom	
  		FDR <- FDR.ancom
	  } 
  
  # -------------------
  # Method of ALDEx2
  # -------------------
  if(method == "ALDEx2") {
    if(length(unique(Y)) == 2){
      otu.table.aldex2 <- t(otu.table)
      conds <- ifelse(Y==0, "A", "B")
      x <- aldex.clr(otu.table.aldex2, conds, mc.samples=128, verbose=TRUE)
      x.tt <- aldex.ttest(x, paired.test=FALSE, hist.plot = FALSE)
      res.aldex2 <- data.frame(x.tt, stringsAsFactors=FALSE)
      if (nrow(res.aldex2) == nrow(otu.table.sim)) {
        otu.aldex2 <- sort(which(res.aldex2$we.eBH < fdr.target))
      }else{
        old.we.eBH <- res.aldex2$we.eBH
        for (idx.i in 1:length(filter.idx)) {
          temp.we.eBH <- old.we.eBH
          new.we.eBH <- insert(temp.we.eBH, filter.idx[idx.i], 100)
          old.we.eBH <- new.we.eBH
        }
        otu.aldex2 <- sort(which(new.we.eBH < fdr.target))
      }
    } else {
      otu.table.aldex2 <- t(otu.table)
      covariates <- data.frame("Y" = Y)
      mm <- model.matrix(~ Y, covariates)
      x <- aldex.clr(otu.table.aldex2, mm, mc.samples=128, verbose=TRUE)
      x.tt <- aldex.glm(x)
      res.aldex2 <- data.frame(x.tt, stringsAsFactors=FALSE)
      
      if (nrow(res.aldex2) == nrow(otu.table.sim)) {
        otu.aldex2 <- sort(which(res.aldex2$model.Y.Pr...t...BH < fdr.target))
      }else{
        old.we.eBH <- res.aldex2$model.Y.Pr...t...BH
        for (idx.i in 1:length(filter.idx)) {
          temp.we.eBH <- old.we.eBH
          new.we.eBH <- insert(temp.we.eBH, filter.idx[idx.i], 100)
          old.we.eBH <- new.we.eBH
        }
        otu.aldex2 <- sort(which(new.we.eBH < fdr.target))
      }
    }
  
    (n.otu.aldex2 = length(otu.aldex2))
    (sen.aldex2 = sum(otu.aldex2 %in% causal.otus.sim)/n.otus.causal.sim)
    (sep.aldex2 = 1- sum(otu.aldex2 %in% non.causal.otus.sim)/n.otus.noncausal.sim)
    (FDR.aldex2 = (n.otu.aldex2 - sum(otu.aldex2 %in% causal.otus.sim))/n.otu.aldex2)
    
    n.otu <- n.otu.aldex2
    sen <- sen.aldex2
    sep <- sep.aldex2	
    FDR <- FDR.aldex2
  }
  
  # ---------------
  # DACOMP
  # ---------------
  if(method == "DACOMP"){
    result.selected.references = dacomp.select_references(
                                 X = otu.table,
                                 median_SD_threshold = median.SD.threshold, #APPLICATION SPECIFIC
                                 verbose = F)
    
    if(length(unique(Y)) == 2){
      res.damp = dacomp.test(X = otu.table, #counts data
                             y = Y, #phenotype in y argument
                             ind_reference_taxa = result.selected.references, 
                             test = DACOMP.TEST.NAME.WILCOXON, #constant, name of test
                             verbose = F,q = 0.05)
    } else {
      res.damp = dacomp.test(X = otu_table, #counts data
                             y = Y, #phenotype in y argument
                             ind_reference_taxa = result.selected.references, 
                             test = DACOMP.TEST.NAME.SPEARMAN, #constant, name of test
                             verbose = F,q = 0.05)
    }
    
    if (length(res.damp$p.values.test) == ncol(otu.table.sim)) {
      temp.q <- p.adjust(res.damp$p.values.test,method = 'BH')

    } else{
      temp.q <- p.adjust(res.damp$p.values.test,method = 'BH')
      for (idx.i in 1:length(filter.idx)) {
        new.q <- insert(temp.q, filter.idx[idx.i], NA)
        temp.q <- new.q
      }
    }
    otu.damp <- sort(which(temp.q  < fdr.target))
    (n.otu.damp = length(otu.damp))
    (sen.damp = sum(otu.damp %in% causal.otus.sim)/n.otus.causal.sim)
    (sep.damp = 1- sum(otu.damp %in% non.causal.otus.sim)/n.otus.noncausal.sim)
    (FDR.damp = (n.otu.damp - sum(otu.damp %in% causal.otus.sim))/n.otu.damp)
    n.otu <- n.otu.damp
    sen <- sen.damp
    sep <- sep.damp	
    FDR <- FDR.damp
  }
  
  # ------------
  # Wrench
  # ------------
  if(method == "WRENCH"){
    res.wrench <- wrench(t(otu.table), Y, z.adj = TRUE)
    res.wrench <- Wilcox(otu.table*res.wrench$nf, Y)
  
    # library(DESeq2) #test via deseq 2.
    # deseq.obj <- DESeq2::DESeqDataSetFromMatrix(countData = (t(otu.table)),
    #                                             DataFrame(Y = factor(Y)),
    #                                             ~ Y )
    # sizeFactors(deseq.obj) <- res.wrench$nf
    # deseq2.res = DESeq2::DESeq(deseq.obj)
    # res.wrench = results(deseq2.res)
    # colnames(res.wrench)[6] <- "adjust.pvalue"
    
    if (length(res.wrench$adjust.pvalue) == ncol(otu.table.sim)) {
      otu.test= sort(which(res.wrench$adjust.pvalue < fdr.target))
    } else{
      old.q <- res.wrench$adjust.pvalue
      for (idx.i in 1:length(filter.idx)) {
        temp.q <- old.q
        new.q <- insert(temp.q, filter.idx[idx.i], 100)
        old.q <- new.q
      }
      otu.test= sort(which(new.q < fdr.target))
    }
    (n.otu.Wrench = length(otu.test))
    (sen.Wrench = sum(otu.test %in% causal.otus.sim)/n.otus.causal.sim)
    (sep.Wrench = 1- sum(otu.test %in% non.causal.otus.sim)/n.otus.noncausal.sim)
    (FDR.Wrench = (n.otu.Wrench - sum(otu.test %in% causal.otus.sim))/n.otu.Wrench)
    n.otu <- n.otu.Wrench
    sen <- sen.Wrench
    sep <- sep.Wrench
    FDR <- FDR.Wrench
  }
  
  # --------------
  # PS
  # --------------
  if(method == "PS"){
    otu.table.ps <- otu.table + ps.count
    otu.table.ps.alr <- log(otu.table.ps/otu.table.ps[,refer.col])
    res.ps <- Wilcox(otu.table.ps.alr, Y)
    if (length(res.ps$adjust.pvalue) == ncol(otu.table.sim)) {
      otu.test= sort(which(res.ps$adjust.pvalue < fdr.target))
    } else{
      old.q <- res.ps$adjust.pvalue
      for (idx.i in 1:length(filter.idx)) {
        temp.q <- old.q
        new.q <- insert(temp.q, filter.idx[idx.i], 100)
        old.q <- new.q
      }
      otu.test= sort(which(new.q < fdr.target))
    }
    (n.otu.ps = length(otu.test))
    (sen.ps = sum(otu.test %in% causal.otus.sim)/n.otus.causal.sim)
    (sep.ps = 1- sum(otu.test %in% non.causal.otus.sim)/n.otus.noncausal.sim)
    (FDR.ps = (n.otu.ps - sum(otu.test %in% causal.otus.sim))/n.otu.ps)
    n.otu <- n.otu.ps
    sen <- sen.ps
    sep <- sep.ps
    FDR <- FDR.ps
  }
  
  # --------------------
  # TSS
  # --------------------
  if(method == "TSS"){
    otu.table.tss <- otu.table/rowSums(otu.table)
    res.tss <- Wilcox(otu.table, Y)
    
    if (length(res.tss$adjust.pvalue) == ncol(otu.table.sim)) {
      otu.test= sort(which(res.tss$adjust.pvalue < fdr.target))
    } else{
      old.q <- res.tss$adjust.pvalue
      for (idx.i in 1:length(filter.idx)) {
        temp.q <- old.q
        new.q <- insert(temp.q, filter.idx[idx.i], 100)
        old.q <- new.q
      }
      otu.test= sort(which(new.q < fdr.target))
    }
    (n.otu.tss = length(otu.test))
    (sen.tss = sum(otu.test %in% causal.otus.sim)/n.otus.causal.sim)
    (sep.tss = 1- sum(otu.test %in% non.causal.otus.sim)/n.otus.noncausal.sim)
    (FDR.tss = (n.otu.tss - sum(otu.test %in% causal.otus.sim))/n.otu.tss)
    n.otu <- n.otu.tss
    sen <- sen.tss
    sep <- sep.tss
    FDR <- FDR.tss
  }
  
  return(list(n.otu = n.otu, sen = sen, sep = sep, FDR = FDR))
}
