filterOTU <- function(otu.table, freq.table, refer.col, censor.thres, freq.thres, eps = 1){
  # Args:
  #  otu.table: simulated otu table
  #  refer.col: chosen referenec otu idx
  #  censor.thres: threshold used to presence and absence
  #  freq.thre: threshold for mean frequency
  #  eps: pseudo count used when there is any 0 in the reference col
  
  n.sam <- nrow(otu.table)
  n.otus <- ncol(otu.table)
  censoring.rate <- apply(otu.table, 2, function(x) sum(x==0)/n.sam) 
  filter.idx <- which(colMeans(freq.table) < freq.thres | censoring.rate > censor.thres)
  cat("There are total", length(filter.idx), "otu will be filter out", "\n")
  
  if(length(filter.idx)>0){
    otuname <- c(1:n.otus)
    names(otuname) <- c(1:n.otus)
    otuname <- otuname[-filter.idx]
    refer.col <- which(otuname == refer.col)
    otu.table.filter <- otu.table[, -filter.idx]
  } else {
    otu.table.filter <- otu.table
  }
  otu.table.filter[which(otu.table.filter[,refer.col]==0), refer.col] <- eps  
  
  
  return(list(otu.table.filter = otu.table.filter, refer.col = refer.col, 
              otuname = otuname, filter.idx = filter.idx, censoring.rate=censoring.rate))
}


SimulateData <- function(otu.freq, 
                         spike.col.only, 
                         spike.confounder.both = NULL,
                         confounder.col.only = NULL,
                         alpha = 3, 
                         gamma = NULL,
                         library.mu = 10000, 
                         library.sd = 10000/3, 
                         lib.sizer.lower = 2000, 
                         disp = 0.02,
                         n.sam = 100,
                         trait = "Bin",
                         frac = 0.5, 
                         dist = "unif",
                         rho = 0.2,
                         bias = FALSE,
                         causal.type,
                         seed){
  # Args:
  #   otu.freq: otu true frequency input
  #   spike.col.only: otu affected by trait 
  #   alpha: effect size of trait variable
  #   gamma: effect size of confounder variable
  #   library.mu: mean library size
  #   library.sd: sd of library size
  #   lib.sizer.lower: lower boundary of library size
  #   disp: overdisperion parameter
  #   n.sam: number of sample simulated
  #   frac: number of control sample simulated
  #   dist: distribution of continuous variable
  #   rho: parameter used to correlation between the trait and confounder
  #   bias: add experimental bias or not
  #   causal.type: causal mechanism:1, 2, 3, 4
  #   seed: random seed
  
  n.otus <- length(otu.freq)
  if(bias == TRUE){
    set.seed(0)
    bias.factor.log <- rnorm(n.otus, 0, 0.8)
    bias.factor.log[spike.col.only] <- rnorm(length(spike.col.only), 1, 0.8)
  }
  if(causal.type %in% c(3,4)){
    set.seed(0)
    alpha <- runif(length(spike.col.only), 1/alpha, alpha)
  }
  
  set.seed(seed)
  pi0 <- otu.freq
  pi1 <- pi0
  n0.sam <- n.sam * frac
  n1.sam <- n.sam * (1 - frac)
  C <- NULL
  
  if(trait == "Bin"){
    Y <- c(rep(0, n0.sam), rep(1, n1.sam))
  }
  
  if(trait == "Cont"){
    if(dist == "unif"){
      Y <- runif(n.sam, -1, 1)
    }
    if(dist == "normal"){
      Y <- rnorm(n.sam, 0, 1)
    }
  }
  
  if(trait == "BinBin"){
    Y <- c(rep(0, n0.sam), rep(1, n1.sam))
    C <- c(rbinom(n0.sam, 1, rho), rbinom(n1.sam, 1, 1 - rho))
  }
  
  if(trait == "BinCont"){
    Y <- c(rep(0, n0.sam), rep(1, n1.sam))
    C <- c(runif(n0.sam, -1, 1), runif(n1.sam, 0, 2))
  }
  
  if(trait == "ContBin"){
    C <- c(rep(0, n0.sam), rep(1, n1.sam))
    Y <- c(runif(n0.sam, -1, 1), runif(n1.sam, 0, 2))
  }
  
  if(trait == "ContCont"){
    Y <- runif(n.sam, -1, 1)
    YY <- runif(n.sam, -1, 1)
    C <- rho * Y + sqrt(1-rho^2) * YY #rho is set to be 0.5 in this case
  }
  
  library.size <- rnorm(n.sam, library.mu, library.sd)
  library.size[library.size < lib.sizer.lower] <- lib.sizer.lower
  library.size <- round(library.size)
  
  alpha.log <- log(alpha)
  if(!is.null(gamma)){
    gamma.log <- log(gamma)
  }
  
  a0 <- (1- disp)/disp
  otu.table.sim.0 = dirmult::rdirichlet(n = n0.sam, a0 * pi0)
  otu.table.sim.1 = dirmult::rdirichlet(n = n1.sam, a0 * pi0)
  otu.table.sim <- rbind(otu.table.sim.0, otu.table.sim.1)
  if(bias == TRUE){
    otu.table.sim <- t(t(otu.table.sim) * exp(bias.factor.log))
  }
  if(causal.type %in% c(1,2)){
    otu.table.sim[ ,spike.col.only] <- otu.table.sim[ ,spike.col.only] * exp(alpha.log * Y)
  } else {
    otu.table.sim[ ,spike.col.only] <- otu.table.sim[ ,spike.col.only] * exp(Y %*% t(alpha.log))
  }
  if(!is.null(gamma)){
    otu.table.sim[ ,spike.confounder.both] <- otu.table.sim[ ,spike.confounder.both] * exp(alpha.log * Y) * exp(gamma.log * C) 
    otu.table.sim[ ,confounder.col.only] <- otu.table.sim[ ,confounder.col.only] * exp(gamma.log * C) 
  }
  otu.table.sim <- otu.table.sim/rowSums(otu.table.sim)
  otu.table.sim.count <- array(0, dim = c(n.sam, n.otus))
  for (i in 1:n.sam) {
    otu.table.sim.count[i, ] <- rmultinom(1, library.size[i], otu.table.sim[i, ])
  }
  otu.table.sim <- otu.table.sim.count
  freq.table.sim <- otu.table.sim/library.size
  
  return(list(otu.table.sim = otu.table.sim, freq.table.sim = freq.table.sim, Y = Y, C = C))
}

# ----------------------------------
# This is a function used to summary the detect results
# Note: at the global null, fdr = 1 when there is any detection (not included in this function)
# ----------------------------------
summarize_otu_results <- function(otuname, qvalue, causal.otus, non.causal.otus, fdr.target=0.1) {
  otu.detected = otuname[which(qvalue < fdr.target)]
  n.otu = length(otu.detected)
  
  # deal with the case when there is no causal otu left
  if(length(causal.otus) > 0){
    sen = sum(otu.detected %in% causal.otus)/length(causal.otus)
  } else {
    sen = 0
  }
  
  sep = 1 - sum(otu.detected %in% non.causal.otus)/length(non.causal.otus)
  fdr = n.otu - sum(otu.detected %in% causal.otus)
  (fdr = fdr/n.otu)
  
  out = list(n.otu = n.otu, sen = sen, sep = sep, fdr = fdr, otu.detected = otu.detected)
  return(out)
}


library(GUniFrac) # Rarefy, GUniFrac
##################################
generate.poisson.lognormal <- function(mu, sigma, n, N) {
  J=length(mu)
  y=mvrnorm(n=n, mu=mu, Sigma=sigma)
  x=N*exp(y)
  otu.tab=matrix( rpois(n=n*J, lambda=x), nrow=n )
  
  res=list( x=x, y=y, otu.tab=otu.tab )
  return(res)
}
##################################

##################################
# read otu table data
# read pi (cell frequencies) and disp (dispersion) 
##################################
SimulateDataPLNM <- function(causal_type, beta, 
                             n_sam, 
                             library_mu, 
                             library_sd, 
                             lib_sizer_lower,
                             have_confounders = 0, 
                             i_seed = 1){
  
  # Args:
  #  otu.table: simulated otu table
  #  refer.col: chosen referenec otu idx
  #  censor.thres: threshold used to presence and absence
  #  freq.thre: threshold for mean frequency
  #  eps: pseudo count used when there is any 0 in the reference col
  
  data(throat.otu.tab)
  data(throat.meta)
  data(throat.tree)
  #if (dist_method=="wt-unifrac") tree=throat.tree
  label <- colnames(throat.otu.tab)
  otu_table <- throat.otu.tab
  freq_table <- t( scale( t(otu_table), center=FALSE, scale=rowSums(otu_table) ) )
  otu_abundance <- colMeans(freq_table)
  
  null_PLNM <- NULL
  null_PLNM$mu <- read.table("./input_throat/fit_PLNM_mu.txt", header=FALSE, as.is=TRUE)[,1]
  null_PLNM$sigma <- read.table("./input_throat/fit_PLNM_sigma.txt", header=FALSE, as.is=TRUE)
  
  n_otus = length(null_PLNM$mu)
  
  
  if (causal_type== 1) { # S1. random half of otus
    top_otus <- order(otu_abundance, decreasing=TRUE)[1:3]
    
    set.seed(123)
    causal_otus = sample(setdiff(1:n_otus, top_otus), size=500, replace=FALSE)
    n_otus_causal = length(causal_otus)
    
    pi4 = null_PLNM$mu # reference
    pi1 = pi4
    pi1[causal_otus]  = sample(pi4[causal_otus], n_otus_causal, replace=FALSE)
    
    causal_otus_shuffle = sample(causal_otus, n_otus_causal, replace=FALSE)
    
    if (have_confounders) {
      confdg_otus = sample(1:n_otus, size=500, replace=FALSE)
      n_otus_confdg1 = length(confdg_otus)
      pi2 = pi4
      pi2[confdg_otus] = sample(pi4[confdg_otus], n_otus_confdg1, replace=FALSE)
    }
  } else if (causal_type==2) { # S2. top ten most abundant otus
    causal_otus = order(otu_abundance, decreasing=TRUE)[c(1:10)]
    n_otus_causal = length(causal_otus)
    
    pi4 = null_PLNM$mu # reference
    pi1 = pi4
    
    set.seed(231)
    pi1[causal_otus]  = sample(pi4[causal_otus], n_otus_causal, replace=FALSE)
    
    causal_otus_shuffle = sample(causal_otus, n_otus_causal, replace=FALSE)
    
    if (have_confounders) {
      confdg_otus = order(otu_abundance, decreasing=TRUE)[11:50]
      n_otus_confdg1 = length(confdg_otus)
      pi2 = pi4
      pi2[confdg_otus] = sample(pi4[confdg_otus], n_otus_confdg1, replace=FALSE)
    }
  }  
  
  ##################################
  # generate simulation data
  ##################################
  
  set.seed(i_seed)
  
  
  lib_sizes_raw <- round(rnorm(n_sam, mean=library_mu, sd=library_sd))
  lib_sizes <- ifelse(lib_sizes_raw < lib_sizer_lower, lib_sizer_lower, lib_sizes_raw)
  
  n_sam_group = n_sam/2
  
  Y = c(rep(0, n_sam_group), rep(1, n_sam_group))
  wtY <- beta 
  p1 = pmin(pmax(wtY*Y, 0),1)
  
  X = runif(n_sam) + 0.5*Y
  
  if (have_confounders){
    wtX <- 0.3
    p2 = pmin(pmax(wtX*X, 0),1-p1)
    p4 = 1-p1-p2
    pi_mixture = p1 %o% pi1 + p2 %o% pi2 + p4 %o% pi4 
  } else {
    p4 = 1-p1
    pi_mixture = p1 %o% pi1 + p4 %o% pi4 
  }
  
  if (beta > 0) {
    otu_table_sim <- generate.poisson.lognormal(mu=null_PLNM$mu, sigma=null_PLNM$sigma, n=n_sam, N=lib_sizes)$otu.tab
    change <- generate.poisson.lognormal(mu=null_PLNM$mu, sigma=null_PLNM$sigma, n=n_sam_group, N=lib_sizes[1:n_sam_group])$otu.tab
    change[, causal_otus] = change[, causal_otus_shuffle]
    r = matrix(runif(n=n_sam_group*length(causal_otus)), nrow=n_sam_group)
    otu_table_sim[1:n_sam_group, causal_otus] = (r>=beta)*otu_table_sim[1:n_sam_group, causal_otus] + (r<beta)*change[,causal_otus]
    
  } else {
    otu_table_sim <- generate.poisson.lognormal(mu=null_PLNM$mu, sigma=null_PLNM$sigma, n=n_sam, N=lib_sizes)$otu.tab
  }
  
  colnames(otu_table_sim) = label
  colnames(otu_table_sim) <- c(1:ncol(otu_table_sim))
  freq_table_sim <- otu_table_sim/rowSums(otu_table_sim)
  
  
  return(list(otu.table.sim = otu_table_sim, freq.table.sim = freq_table_sim, Y = Y, causal.otus.sim =  causal_otus))
}  
