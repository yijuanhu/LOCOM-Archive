# ----------------------------
# Binary Setting Simulation
# ----------------------------
library(psych)
library(dirmult) # simPop
library(Rcpp)
library(RcppArmadillo)
library(R.utils) 
library(metap)
library(psych)
library(vegan)
library(ANCOMBC)
library(phyloseq)

source("useful_function.R")
source("Method_Comparison_Noconfounder.R")
source("wilcox.R")
source("ancom_v2.1.R")

test_global <- 1
test_otu <- 1
causal_type <- 1    # simulation scenario
library_mu <- 10000 # mean of library size
disp <- 0.02        # dispersion parameter
n_sam <- 100        # total sample size
alpha <- 3          # effect size 
freq_thres <- 0     # frequency threshold
censor_thres <- 0.8 # presence/absence threshold
ss <- 3             
library_sd = library_mu/ss # standard error in library size 
lib_sizer_lower = 2000     # lower bound for library size
fdr_target <- 0.2 # nominal fdr value

n_sim <- 1
for (i_seed in 1:n_sim) {
  cat("i_seed",i_seed,"\n")
   
  # ----------------------------
  # Set frequency value
  # ----------------------------
  pi <- read.table("input_throat/fit_dirmult_pi.txt", header=FALSE, as.is=TRUE)[,1]
  n_otus = length(pi)
  
  # ----------------------------
  # causal type specification
  # ----------------------------
  if(causal_type == 1){
    random.col <- c(which(pi >= 0.005))[c(1:20)]
    spike.col <- random.col                
  } 
  
  if(causal_type == 2){
    random.col <- order(pi, decreasing = TRUE)[1:5]
    spike.col <- random.col
  }
  
  if(causal_type == 3){
    set.seed(0)
    random.col <- sort(sample(1:856, 500))
    spike.col <- random.col  
  }
  
  if(causal_type == 4){
    random.col <- c(which(pi >= 0.001 & pi <= 0.002))[c(1:20)]
    spike.col <- random.col 
  }
  
  
  causal_otus_sim = c(spike.col)
  n_otus_causal_sim = length(causal_otus_sim)
  non_causal_otus_sim = setdiff(1:n_otus, causal_otus_sim)
  n_otus_noncausal_sim = length(non_causal_otus_sim)
  
  # -----------------------------
  # Simulate Data
  # -----------------------------
  simData <- Simulation_Binary(otu_freq = pi, spike.col = spike.col, alpha = alpha, library_mu = library_mu, library_sd = library_sd, lib_sizer_lower = lib_sizer_lower, disp = disp, n_sam = n_sam, frac = 0.5, seed = i_seed)
  otu_table_sim <- simData$otu_table_sim
  freq_table_sim <- simData$freq_table_sim
  Y <- simData$Y
  B <- simData$B
  BB_t <- simData$BB_t
  
  # -----------------------------
  # Filter Data
  # -----------------------------
  filterData <- filter_otu(otu_table = otu_table_sim, freq_table = freq_table_sim, refer.col =  468, freq_thres = freq_thres, censor_thres = censor_thres, eps = 1)
  otu_table_sim_filter <- filterData$otu_table_filter
  refer.col <- filterData$refer.col
  otuname <- filterData$otuname
  filter.idx <- filterData$filter.idx
  censoring_rate <- filterData$censoring_rate
  causal_otus_sim_filter <- causal_otus_sim[!causal_otus_sim %in% filter.idx]
  non_causal_otus_sim_filter <- non_causal_otus_sim[!non_causal_otus_sim %in% filter.idx]
  cat("number of causal otu:", length(causal_otus_sim_filter), "\n") 
  # -----------------------------
  
  # -----------------------------
  # Global Test
  # -----------------------------
  if(test_global == 1){
	  ps_count <- 0.5
	  otu_table_sim_filter_ps <- otu_table_sim_filter + ps_count
	  otu_table_sim_filter_clr <-  log(otu_table_sim_filter_ps) - apply(otu_table_sim_filter_ps, 1, function(x) mean(log(x)))
	  set.seed(0)
	  design <- data.frame(Y = Y)
	  otu.dist <- vegdist(otu_table_sim_filter, method='euclidean')
	  res <- adonis2(otu.dist ~ Y , data= design, permutations = 9999, method="euclidean")
	  pvalue1 <- res$`Pr(>F)`[1]
	  
	  ps_count <- 1
	  otu_table_sim_filter_ps <- otu_table_sim_filter + ps_count
	  otu_table_sim_filter_clr <-  log(otu_table_sim_filter_ps) - apply(otu_table_sim_filter_ps, 1, function(x) mean(log(x)))
	  set.seed(0)
	  design <- data.frame(Y = Y)
	  otu.dist <- vegdist(otu_table_sim_filter, method='euclidean')
	  res <- adonis2(otu.dist ~ Y , data= design, permutations = 9999, method="euclidean")
	  pvalue2 <- res$`Pr(>F)`[1]
    
	  global.pvalue <- c(pvalue1, pvalue2)
	}
  # -----------------------------
  # OTU Test 
  # -----------------------------
  n_otus_causal_sim_filter <- length(causal_otus_sim_filter)
  n_otus_noncausal_sim_filter <- length(non_causal_otus_sim)
  if(test_otu == 1){
	  res.aldex2 <- Method_Comparsion_NoConfounder(otu_table = otu_table_sim_filter, otu_table_sim = otu_table_sim, 
	                                               filter.idx = filter.idx, Y = Y, fdr_target = fdr_target, method = "ALDEx2", 
												                         causal_otus_sim = causal_otus_sim_filter, 
												                         n_otus_causal_sim = n_otus_causal_sim_filter, 
												                         non_causal_otus_sim = non_causal_otus_sim_filter, 
												                         n_otus_noncausal_sim = n_otus_noncausal_sim_filter)
	  
	  res.ancom <- Method_Comparsion_NoConfounder(otu_table = otu_table_sim_filter, otu_table_sim = otu_table_sim, 
	                                              filter.idx = filter.idx, Y = Y, fdr_target = fdr_target, method = "ANCOM", 
												                        causal_otus_sim = causal_otus_sim_filter, 
												                        n_otus_causal_sim = n_otus_causal_sim_filter, 
												                        non_causal_otus_sim = non_causal_otus_sim_filter, 
												                        n_otus_noncausal_sim = n_otus_noncausal_sim_filter, filter = "LOCOM")
	  
	  res.dacomp <- Method_Comparsion_NoConfounder(otu_table = otu_table_sim_filter, otu_table_sim = otu_table_sim, 
	                                               filter.idx = filter.idx, Y = Y, fdr_target = fdr_target, method = "DACOMP", 
												                         causal_otus_sim = causal_otus_sim_filter,
												                         n_otus_causal_sim = n_otus_causal_sim_filter, 
												                         non_causal_otus_sim = non_causal_otus_sim_filter, 
												                         n_otus_noncausal_sim = n_otus_noncausal_sim_filter)
	  
	  res.wrench <- Method_Comparsion_NoConfounder(otu_table = otu_table_sim_filter, otu_table_sim = otu_table_sim,
	                                               filter.idx = filter.idx, Y = Y, fdr_target = fdr_target, method = "WRENCH", 
												                         causal_otus_sim = causal_otus_sim_filter, 
												                         n_otus_causal_sim = n_otus_causal_sim_filter, 
												                         non_causal_otus_sim = non_causal_otus_sim_filter, 
												                         n_otus_noncausal_sim = n_otus_noncausal_sim_filter)
	  
	  res.ancombc <- Method_Comparsion_NoConfounder(otu_table = otu_table_sim_filter, otu_table_sim = otu_table_sim, 
	                                                filter.idx = filter.idx, Y = Y, fdr_target = fdr_target, method = "ANCOMBC", 
												                          causal_otus_sim = causal_otus_sim, 
												                          n_otus_causal_sim = n_otus_causal_sim, 
												                          non_causal_otus_sim = non_causal_otus_sim, 
												                          n_otus_noncausal_sim = n_otus_noncausal_sim, filter = "LOCOM")

	  res.ancom2 <- Method_Comparsion_NoConfounder(otu_table = otu_table_sim_filter, otu_table_sim = otu_table_sim, 
	                                               filter.idx = filter.idx, Y = Y, fdr_target = fdr_target, method = "ANCOM", 
												                         causal_otus_sim = causal_otus_sim, 
												                         n_otus_causal_sim = n_otus_causal_sim, 
												                         non_causal_otus_sim = non_causal_otus_sim, 
												                         n_otus_noncausal_sim = n_otus_noncausal_sim, filter = "ANCOM")
      
	  res.ancombc2 <- Method_Comparsion_NoConfounder(otu_table = otu_table_sim_filter, otu_table_sim = otu_table_sim, 
	                                                 filter.idx = filter.idx, Y = Y, fdr_target = fdr_target, method = "ANCOMBC", 
												                           causal_otus_sim = causal_otus_sim, 
												                           n_otus_causal_sim = n_otus_causal_sim, 
												                           non_causal_otus_sim = non_causal_otus_sim, 
												                           n_otus_noncausal_sim = n_otus_noncausal_sim, filter = "ANCOM")
    
	  res.ps.5 <- Method_Comparsion_NoConfounder(otu_table = otu_table_sim_filter, otu_table_sim = otu_table_sim, 
	                                                 filter.idx = filter.idx, Y = Y, fdr_target = fdr_target, method = "PS", 
	                                                 causal_otus_sim = causal_otus_sim, 
	                                                 n_otus_causal_sim = n_otus_causal_sim, 
	                                                 non_causal_otus_sim = non_causal_otus_sim, 
	                                                 n_otus_noncausal_sim = n_otus_noncausal_sim, ps.count = 0.5)
		
	  res.ps.10 <- Method_Comparsion_NoConfounder(otu_table = otu_table_sim_filter, otu_table_sim = otu_table_sim, 
	                                                 filter.idx = filter.idx, Y = Y, fdr_target = fdr_target, method = "PS", 
	                                                 causal_otus_sim = causal_otus_sim, 
	                                                 n_otus_causal_sim = n_otus_causal_sim, 
	                                                 non_causal_otus_sim = non_causal_otus_sim, 
	                                                 n_otus_noncausal_sim = n_otus_noncausal_sim, ps.count = 1)
	  
	  res.tss <- Method_Comparsion_NoConfounder(otu_table = otu_table_sim_filter, otu_table_sim = otu_table_sim, 
	                                             filter.idx = filter.idx, Y = Y, fdr_target = fdr_target, method = "TSS", 
	                                             causal_otus_sim = causal_otus_sim, 
	                                             n_otus_causal_sim = n_otus_causal_sim, 
	                                             non_causal_otus_sim = non_causal_otus_sim, 
	                                             n_otus_noncausal_sim = n_otus_noncausal_sim)

	    mat <- rbind(unlist(res.aldex2), 
				      unlist(res.ancom),
				      unlist(res.dacomp),
				      unlist(res.wrench),
				      unlist(res.ancombc),
				      unlist(res.ancom2),
				      unlist(res.ancombc2),
				      unlist(res.tss), 
				      unlist(res.ps.5),
				      unlist(res.ps.10))
	}
}
