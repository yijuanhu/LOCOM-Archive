# ----------------------------------
# This is a function used to summary global test and individual test results for different filtering critertion
# ----------------------------------
#summarize_results <- function(obs_stats, perm_stats, sim = TRUE, )

# ----------------------------------
# This is a function used to summary the detect results
# ----------------------------------
summarize_otu_results <- function(otuname, qvalue, causal_otus, non_causal_otus, fdr_target=0.1) {
  otu_detected = otuname[which(qvalue < fdr_target)]
  n_otu = length(otu_detected)
  
  # deal with the case when there is no causal otu left
  if(length(causal_otus) > 0){
	  sen = sum(otu_detected %in% causal_otus)/length(causal_otus)
  } else {
    sen = 0
  }

  sep = 1 - sum(otu_detected %in% non_causal_otus)/length(non_causal_otus)
  fdr = n_otu - sum(otu_detected %in% causal_otus)
  (fdr = fdr/n_otu)

  out = list(n_otu = n_otu, sen = sen, sep = sep, fdr = fdr, otu_detected = otu_detected)
  return(out)
}

# -----------------------------------
# This is a function used to filter simulated otu table
# -----------------------------------
filter_otu <- function(otu_table, freq_table, refer.col, censor_thres, freq_thres, eps = 1){
  # Args:
  #  otu_table: simulated otu table
  #  refer.col: chosen referenec otu idx
  #  censor_thres: threshold used to presence and absence
  #  freq_thres: threshold for mean frequency
  #  eps: pseudo count used when there is any 0 in the reference col
  
  n_sam <- nrow(otu_table)
  n_otus <- ncol(otu_table)
  censoring_rate <- apply(otu_table, 2, function(x) sum(x==0)/n_sam) 
  filter.idx <- which(colMeans(freq_table) < freq_thres | censoring_rate > censor_thres)
  cat("There are total", length(filter.idx), "otu will be filter out", "\n")
  
  if(length(filter.idx)>0){
    otuname <- c(1:n_otus)
    names(otuname) <- c(1:n_otus)
    otuname <- otuname[-filter.idx]
    refer.col <- which(otuname == refer.col)
    otu_table_filter <- otu_table[, -filter.idx]
  } else {
    otu_table_filter <- otu_table
  }
  otu_table_filter[which(otu_table_filter[,refer.col]==0), refer.col] <- eps  
  return(list(otu_table_filter = otu_table_filter, refer.col = refer.col, otuname = otuname, filter.idx = filter.idx, censoring_rate=censoring_rate))
}

# -----------------------------------
# This is a function used to simulate the setting when there is a binary trait
# -----------------------------------
Simulation_Binary <- function(otu_freq, spike.col, alpha = 3, 
                              library_mu = 10000, library_sd = 10000/3, lib_sizer_lower = 2000, disp = 0.02,
                              n_sam = 100, frac = 0.5, seed){
  # Args:
  #   otu_freq: otu true frequency input
  #   spike.col: otu affected by trait 
  #   alpha: effect size of trait variable
  #   gamma: effect size of confounder variable
  #   library_mu: mean library size
  #   library_sd: sd of library size
  #   lib_sizer_lower: lower boundary of library size
  #   disp: overdisperion parameter
  #   n_sam: number of sample simulated
  #   frac: number of control sample simulated
  #   seed: random seed
  
  set.seed(seed)
  pi0 <- otu_freq
  pi1 <- pi0
  
  n0_sam <- n_sam * frac
  n1_sam <- n_sam * (1 - frac)
  
  Y <- c(rep(0, n0_sam), rep(1, n1_sam))
  
  B <- array(rep(1,n_sam), dim=c(n_sam,1))
  B <- cbind(B, Y)
  KK <- ncol(B)
  BB <- array(0, dim = c(n_sam, KK, KK))
  BB_t <- array(0, dim = c(KK, KK, n_sam))
  for(i in 1:n_sam){
    temp <- B[i, ]%*% t(B[i,])
    BB_t[,,i] <- temp
    BB[i,,] <- temp
  }
  
  # ------------------------
  # simulation library size
  # ------------------------
  library_size <- rnorm(n_sam, library_mu, library_sd)
  library_size[library_size < lib_sizer_lower] <- lib_sizer_lower
  library_size <- round(library_size)
  
  # ------------------------
  # simulate data
  # ------------------------
  alpha_log <- log(alpha)
  
  a0 <- (1- disp)/disp
  otu_table_sim_0 = dirmult::rdirichlet(n = n0_sam, a0 * pi0)
  otu_table_sim_1 = dirmult::rdirichlet(n = n1_sam, a0 * pi0)
  otu_table_sim <- rbind(otu_table_sim_0, otu_table_sim_1)
  otu_table_sim[ ,spike.col] <- otu_table_sim[ ,spike.col] * exp(alpha_log * Y)
  otu_table_sim <- otu_table_sim/rowSums(otu_table_sim)
  otu_table_sim_count <- array(0, dim = c(n_sam, n_otus))
  for (i in 1:n_sam) {
    otu_table_sim_count[i, ] <- rmultinom(1, library_size[i], otu_table_sim[i, ])
  }
  otu_table_sim <- otu_table_sim_count
  freq_table_sim <- otu_table_sim/library_size
  
  return(list(otu_table_sim = otu_table_sim, freq_table_sim = freq_table_sim, Y = Y, B = B, BB_t = BB_t))
}


# -----------------------------------
# This is a function used to simulate the setting when there is a binary trait and a binary confounder
# -----------------------------------
Simulation_Binary_Confounder <- function(otu_freq, spike.col.only, confounder.col.only, spike.confounder.both, alpha = 3, gamma = 3, 
                                         library_mu = 10000, library_sd = 10000/3, lib_sizer_lower = 2000, disp = 0.02,
                                         n_sam = 100, frac = 0.5, rho = 0.2, seed){
  # Args:
  #   otu_freq: otu true frequency input
  #   spike.col.only: otu affected by trait 
  #   confounder.col.only: otu affected by counfoudner
  #   spike.confounder.both: otu affected by both trait and confoudner
  #   alpha: effect size of trait variable
  #   gamma: effect size of confounder variable
  #   library_mu: mean library size
  #   library_sd: sd of library size
  #   lib_sizer_lower: lower boundary of library size
  #   disp: overdisperion parameter
  #   n_sam: number of sample simulated
  #   frac: number of control sample simulated
  #   rho: correlation between the trait and confounder
  #   seed: random seed
  
  set.seed(seed)
  pi0 <- otu_freq
  pi1 <- pi0
  
  n0_sam <- n_sam * frac
  n1_sam <- n_sam * (1 - frac)
  
  Y = c(rep(0, n0_sam), rep(1, n1_sam))
  C <- c(rbinom(n0_sam, 1, rho), rbinom(n1_sam, 1, 1 -rho))
  
  B <- array(rep(1,n_sam), dim=c(n_sam,1))
  B <- cbind(B, Y, C)
  KK <- ncol(B)
  BB <- array(0, dim = c(n_sam, KK, KK))
  BB_t <- array(0, dim = c(KK, KK, n_sam))
  for(i in 1:n_sam){
    temp <- B[i, ]%*% t(B[i,])
    BB_t[,,i] <- temp
    BB[i,,] <- temp
  }
  
  # ------------------------
  # simulation library size
  # ------------------------
  library_size <- rnorm(n_sam, library_mu, library_sd)
  library_size[library_size < lib_sizer_lower] <- lib_sizer_lower
  library_size <- round(library_size)
  
  # ------------------------
  # simulate data
  # ------------------------
  alpha_log <- log(alpha)
  gamma_log <- log(gamma)
  
  a0 <- (1- disp)/disp
  otu_table_sim_0 = dirmult::rdirichlet(n = n0_sam, a0 * pi0)
  otu_table_sim_1 = dirmult::rdirichlet(n = n1_sam, a0 * pi0)
  otu_table_sim <- rbind(otu_table_sim_0, otu_table_sim_1)
  otu_table_sim[ ,spike.col.only] <- otu_table_sim[ ,spike.col.only] * exp(alpha_log * Y)
  otu_table_sim[ ,spike.confounder.both] <- otu_table_sim[ ,spike.confounder.both] * exp(alpha_log * Y) * exp(gamma_log * C) 
  otu_table_sim[ ,confounder.col.only] <- otu_table_sim[ ,confounder.col.only] * exp(gamma_log * C) 
  otu_table_sim <- otu_table_sim/rowSums(otu_table_sim)
  otu_table_sim_count <- array(0, dim = c(n_sam, n_otus))
  for (i in 1:n_sam) {
    otu_table_sim_count[i, ] <- rmultinom(1, library_size[i], otu_table_sim[i, ])
  }
  otu_table_sim <- otu_table_sim_count
  freq_table_sim <- otu_table_sim/library_size
  
  return(list(otu_table_sim = otu_table_sim, freq_table_sim = freq_table_sim, Y = Y, C = C, B = B, BB_t = BB_t))
}

# -----------------------------------
# This is a function used to simulate the setting when there is a binary trait and a binary confounder and effect size are differential 
# -----------------------------------
Simulation_Binary_Confounder_differential <- function(otu_freq, spike.col.only, confounder.col.only, spike.confounder.both, alpha1 = 3, gamma1 = 3, alpha2 = 3, gamma2 = 3, 
													  library_mu = 10000, library_sd = 10000/3, lib_sizer_lower = 2000, disp = 0.02,
													  n_sam = 100, frac = 0.5, rho = 0.2, seed){
  # Args:
  #   otu_freq: otu true frequency input
  #   spike.col.only: otu affected by trait 
  #   confounder.col.only: otu affected by counfoudner
  #   spike.confounder.both: otu affected by both trait and confoudner
  #   alpha: effect size of trait variable
  #   gamma: effect size of confounder variable
  #   library_mu: mean library size
  #   library_sd: sd of library size
  #   lib_sizer_lower: lower boundary of library size
  #   disp: overdisperion parameter
  #   n_sam: number of sample simulated
  #   frac: number of control sample simulated
  #   rho: correlation between the trait and confounder
  #   seed: random seed
  
  set.seed(seed)
  pi0 <- otu_freq
  pi1 <- pi0
  
  n0_sam <- n_sam * frac
  n1_sam <- n_sam * (1 - frac)
  
  Y = c(rep(0, n0_sam), rep(1, n1_sam))
  C <- c(rbinom(n0_sam, 1, rho), rbinom(n1_sam, 1, 1 -rho))
  
  B <- array(rep(1,n_sam), dim=c(n_sam,1))
  B <- cbind(B, Y, C)
  KK <- ncol(B)
  BB <- array(0, dim = c(n_sam, KK, KK))
  BB_t <- array(0, dim = c(KK, KK, n_sam))
  for(i in 1:n_sam){
    temp <- B[i, ]%*% t(B[i,])
    BB_t[,,i] <- temp
    BB[i,,] <- temp
  }
  
  # ------------------------
  # simulation library size
  # ------------------------
  library_size <- rnorm(n_sam, library_mu, library_sd)
  library_size[library_size < lib_sizer_lower] <- lib_sizer_lower
  library_size <- round(library_size)
  
  # ------------------------
  # simulate data
  # ------------------------
  alpha1_log <- log(alpha1)
  gamma1_log <- log(gamma1)
  alpha2_log <- log(alpha2)
  gamma2_log <- log(gamma2)
  
  a0 <- (1- disp)/disp
  otu_table_sim_0 = dirmult::rdirichlet(n = n0_sam, a0 * pi0)
  otu_table_sim_1 = dirmult::rdirichlet(n = n1_sam, a0 * pi0)
  otu_table_sim <- rbind(otu_table_sim_0, otu_table_sim_1)
  
  otu_table_sim[ ,spike.col.only] <- otu_table_sim[ ,spike.col.only] * exp(Y %*% t(alpha1_log))
  otu_table_sim[ ,confounder.col.only] <- otu_table_sim[ ,confounder.col.only] * exp(C %*% t(gamma1_log))
  otu_table_sim[ ,spike.confounder.both] <- otu_table_sim[ ,spike.confounder.both] * exp(Y %*% t(alpha2_log)) * exp(C %*% t(gamma2_log)) 
   
   
  otu_table_sim <- otu_table_sim/rowSums(otu_table_sim)
  otu_table_sim_count <- array(0, dim = c(n_sam, n_otus))
  for (i in 1:n_sam) {
    otu_table_sim_count[i, ] <- rmultinom(1, library_size[i], otu_table_sim[i, ])
  }
  otu_table_sim <- otu_table_sim_count
  freq_table_sim <- otu_table_sim/library_size
  
  return(list(otu_table_sim = otu_table_sim, freq_table_sim = freq_table_sim, Y = Y, C = C, B = B, BB_t = BB_t))
}

# -----------------------------------
# This is a function used to simulate the setting when there is a continuous trait
# -----------------------------------
Simulation_Cont <- function(otu_freq, spike.col, alpha = 3, 
                              library_mu = 10000, library_sd = 10000/3, lib_sizer_lower = 2000, disp = 0.02,
                              n_sam = 100, frac = 0.5, seed, dist = "unif"){
  # Args:
  #   otu_freq: otu true frequency input
  #   spike.col: otu affected by trait 
  #   alpha: effect size of trait variable
  #   gamma: effect size of confounder variable
  #   library_mu: mean library size
  #   library_sd: sd of library size
  #   lib_sizer_lower: lower boundary of library size
  #   disp: overdisperion parameter
  #   n_sam: number of sample simulated
  #   frac: number of control sample simulated
  #   seed: random seed
  #   dist: distribution of continuous variable
  
  set.seed(seed)
  pi0 <- otu_freq
  pi1 <- pi0
  
  if(dist == "unif"){
    Y <- runif(n_sam, -1, 1)
  }
  if(dist == "normal"){
    Y <- rnorm(n_sam, 0, 1)
  }
  
  B <- array(rep(1,n_sam), dim=c(n_sam,1))
  B <- cbind(B, Y)
  KK <- ncol(B)
  BB <- array(0, dim = c(n_sam, KK, KK))
  BB_t <- array(0, dim = c(KK, KK, n_sam))
  for(i in 1:n_sam){
    temp <- B[i, ]%*% t(B[i,])
    BB_t[,,i] <- temp
    BB[i,,] <- temp
  }
  
  # ------------------------
  # simulation library size
  # ------------------------
  library_size <- rnorm(n_sam, library_mu, library_sd)
  library_size[library_size < lib_sizer_lower] <- lib_sizer_lower
  library_size <- round(library_size)
  
  # ------------------------
  # simulate data
  # ------------------------
  alpha_log <- log(alpha)
  
  a0 <- (1- disp)/disp
  #otu_table_sim_0 = dirmult::rdirichlet(n = n0_sam, a0 * pi0)
  #otu_table_sim_1 = dirmult::rdirichlet(n = n1_sam, a0 * pi0)
  #otu_table_sim <- rbind(otu_table_sim_0, otu_table_sim_1)
  otu_table_sim <- dirmult::rdirichlet(n = n_sam, a0 * pi0)
  otu_table_sim[ ,spike.col] <- otu_table_sim[ ,spike.col] * exp(alpha_log * Y)
  otu_table_sim <- otu_table_sim/rowSums(otu_table_sim)
  otu_table_sim_count <- array(0, dim = c(n_sam, n_otus))
  for (i in 1:n_sam) {
    otu_table_sim_count[i, ] <- rmultinom(1, library_size[i], otu_table_sim[i, ])
  }
  otu_table_sim <- otu_table_sim_count
  freq_table_sim <- otu_table_sim/library_size
  
  return(list(otu_table_sim = otu_table_sim, freq_table_sim = freq_table_sim, Y = Y, B = B, BB_t = BB_t))
}

# -----------------------------------
# This is a function used to simulate the setting when there is a continuous trait and a continuous confounder
# -----------------------------------
Simulation_Cont_Cont <- function(otu_freq, spike.col.only, confounder.col.only, spike.confounder.both, alpha = 3, gamma = 3, 
                                         library_mu = 10000, library_sd = 10000/3, lib_sizer_lower = 2000, disp = 0.02,
                                         n_sam = 100, frac = 0.5, rho = 0.2, seed){
  # Args:
  #   otu_freq: otu true frequency input
  #   spike.col.only: otu affected by trait 
  #   confounder.col.only: otu affected by counfoudner
  #   spike.confounder.both: otu affected by both trait and confoudner
  #   alpha: effect size of trait variable
  #   gamma: effect size of confounder variable
  #   library_mu: mean library size
  #   library_sd: sd of library size
  #   lib_sizer_lower: lower boundary of library size
  #   disp: overdisperion parameter
  #   n_sam: number of sample simulated
  #   frac: number of control sample simulated
  #   rho: correlation between the trait and confounder
  #   seed: random seed
  
  set.seed(seed)
  pi0 <- otu_freq
  pi1 <- pi0
  
  n0_sam <- n_sam * frac
  n1_sam <- n_sam * (1 - frac)
  
  Y <- runif(n_sam, -1, 1)
  YY <- runif(n_sam, -1, 1)
  C <- rho * Y + sqrt(1-rho^2) * YY
  
  
  B <- array(rep(1,n_sam), dim=c(n_sam,1))
  B <- cbind(B, Y, C)
  KK <- ncol(B)
  BB <- array(0, dim = c(n_sam, KK, KK))
  BB_t <- array(0, dim = c(KK, KK, n_sam))
  for(i in 1:n_sam){
    temp <- B[i, ]%*% t(B[i,])
    BB_t[,,i] <- temp
    BB[i,,] <- temp
  }
  
  # ------------------------
  # simulation library size
  # ------------------------
  library_size <- rnorm(n_sam, library_mu, library_sd)
  library_size[library_size < lib_sizer_lower] <- lib_sizer_lower
  library_size <- round(library_size)
  
  # ------------------------
  # simulate data
  # ------------------------
  alpha_log <- log(alpha)
  gamma_log <- log(gamma)
  
  a0 <- (1- disp)/disp
  otu_table_sim_0 = dirmult::rdirichlet(n = n0_sam, a0 * pi0)
  otu_table_sim_1 = dirmult::rdirichlet(n = n1_sam, a0 * pi0)
  otu_table_sim <- rbind(otu_table_sim_0, otu_table_sim_1)
  otu_table_sim[ ,spike.col.only] <- otu_table_sim[ ,spike.col.only] * exp(alpha_log * Y)
  otu_table_sim[ ,spike.confounder.both] <- otu_table_sim[ ,spike.confounder.both] * exp(alpha_log * Y) * exp(gamma_log * C) 
  otu_table_sim[ ,confounder.col.only] <- otu_table_sim[ ,confounder.col.only] * exp(gamma_log * C) 
  otu_table_sim <- otu_table_sim/rowSums(otu_table_sim)
  otu_table_sim_count <- array(0, dim = c(n_sam, n_otus))
  for (i in 1:n_sam) {
    otu_table_sim_count[i, ] <- rmultinom(1, library_size[i], otu_table_sim[i, ])
  }
  otu_table_sim <- otu_table_sim_count
  freq_table_sim <- otu_table_sim/library_size
  
  return(list(otu_table_sim = otu_table_sim, freq_table_sim = freq_table_sim, Y = Y, C = C, B = B, BB_t = BB_t))
}

# -----------------------------------
# This is a function used to simulate the setting when there is a continuous trait and a binary confounder
# -----------------------------------
Simulation_Cont_Binary <- function(otu_freq, spike.col.only, confounder.col.only, spike.confounder.both, alpha = 3, gamma = 3, 
                                         library_mu = 10000, library_sd = 10000/3, lib_sizer_lower = 2000, disp = 0.02,
                                         n_sam = 100, frac = 0.5, rho = 0.2, seed){
  # Args:
  #   otu_freq: otu true frequency input
  #   spike.col.only: otu affected by trait 
  #   confounder.col.only: otu affected by counfoudner
  #   spike.confounder.both: otu affected by both trait and confoudner
  #   alpha: effect size of trait variable
  #   gamma: effect size of confounder variable
  #   library_mu: mean library size
  #   library_sd: sd of library size
  #   lib_sizer_lower: lower boundary of library size
  #   disp: overdisperion parameter
  #   n_sam: number of sample simulated
  #   frac: number of control sample simulated
  #   rho: correlation between the trait and confounder
  #   seed: random seed
  
  set.seed(seed)
  pi0 <- otu_freq
  pi1 <- pi0
  
  n0_sam <- n_sam * frac
  n1_sam <- n_sam * (1 - frac)
  
  C = c(rep(0, n0_sam), rep(1, n1_sam))
  Y <- c(runif(n0_sam, -1, 1), runif(n1_sam, 0, 2))
  
  B <- array(rep(1,n_sam), dim=c(n_sam,1))
  B <- cbind(B, Y, C)
  KK <- ncol(B)
  BB <- array(0, dim = c(n_sam, KK, KK))
  BB_t <- array(0, dim = c(KK, KK, n_sam))
  for(i in 1:n_sam){
    temp <- B[i, ]%*% t(B[i,])
    BB_t[,,i] <- temp
    BB[i,,] <- temp
  }
  
  # ------------------------
  # simulation library size
  # ------------------------
  library_size <- rnorm(n_sam, library_mu, library_sd)
  library_size[library_size < lib_sizer_lower] <- lib_sizer_lower
  library_size <- round(library_size)
  
  # ------------------------
  # simulate data
  # ------------------------
  alpha_log <- log(alpha)
  gamma_log <- log(gamma)
  
  a0 <- (1- disp)/disp
  otu_table_sim_0 = dirmult::rdirichlet(n = n0_sam, a0 * pi0)
  otu_table_sim_1 = dirmult::rdirichlet(n = n1_sam, a0 * pi0)
  otu_table_sim <- rbind(otu_table_sim_0, otu_table_sim_1)
  otu_table_sim[ ,spike.col.only] <- otu_table_sim[ ,spike.col.only] * exp(alpha_log * Y)
  otu_table_sim[ ,spike.confounder.both] <- otu_table_sim[ ,spike.confounder.both] * exp(alpha_log * Y) * exp(gamma_log * C) 
  otu_table_sim[ ,confounder.col.only] <- otu_table_sim[ ,confounder.col.only] * exp(gamma_log * C) 
  otu_table_sim <- otu_table_sim/rowSums(otu_table_sim)
  otu_table_sim_count <- array(0, dim = c(n_sam, n_otus))
  for (i in 1:n_sam) {
    otu_table_sim_count[i, ] <- rmultinom(1, library_size[i], otu_table_sim[i, ])
  }
  otu_table_sim <- otu_table_sim_count
  freq_table_sim <- otu_table_sim/library_size
  
  return(list(otu_table_sim = otu_table_sim, freq_table_sim = freq_table_sim, Y = Y, C = C, B = B, BB_t = BB_t))
}


# -----------------------------------
# This is a function used to simulate the setting when there is a binary trait and a continuous confounder
# -----------------------------------
Simulation_Cont_Confounder <- function(otu_freq, spike.col.only, confounder.col.only, spike.confounder.both, alpha = 3, gamma = 3, sign = 1, 
                                         library_mu = 10000, library_sd = 10000/3, lib_sizer_lower = 2000, disp = 0.02,
                                         n_sam = 100, frac = 0.5, rho = 0.2, seed){
  # Args:
  #   otu_freq: otu true frequency input
  #   spike.col.only: otu affected by trait 
  #   confounder.col.only: otu affected by counfoudner
  #   spike.confounder.both: otu affected by both trait and confoudner
  #   alpha: effect size of trait variable
  #   gamma: effect size of confounder variable
  #   sign: direction of effect size 1: postive; -1: negative
  #   library_mu: mean library size
  #   library_sd: sd of library size
  #   lib_sizer_lower: lower boundary of library size
  #   disp: overdisperion parameter
  #   n_sam: number of sample simulated
  #   frac: number of control sample simulated
  #   rho: correlation between the trait and confounder
  #   seed: random seed
  
  set.seed(seed)
  pi0 <- otu_freq
  pi1 <- pi0
  
  n0_sam <- n_sam * frac
  n1_sam <- n_sam * (1 - frac)
  
  Y = c(rep(0, n0_sam), rep(1, n1_sam))
  C <- c(runif(n0_sam, -1, 1), runif(n1_sam, 0, 2))
  
  B <- array(rep(1,n_sam), dim=c(n_sam,1))
  B <- cbind(B, Y, C)
  KK <- ncol(B)
  BB <- array(0, dim = c(n_sam, KK, KK))
  BB_t <- array(0, dim = c(KK, KK, n_sam))
  for(i in 1:n_sam){
    temp <- B[i, ]%*% t(B[i,])
    BB_t[,,i] <- temp
    BB[i,,] <- temp
  }
  
  # ------------------------
  # simulation library size
  # ------------------------
  library_size <- rnorm(n_sam, library_mu, library_sd)
  library_size[library_size < lib_sizer_lower] <- lib_sizer_lower
  library_size <- round(library_size)
  
  # ------------------------
  # simulate data
  # ------------------------
  alpha_log <- log(alpha)
  gamma_log <- log(gamma)
  
  a0 <- (1- disp)/disp
  otu_table_sim_0 = dirmult::rdirichlet(n = n0_sam, a0 * pi0)
  otu_table_sim_1 = dirmult::rdirichlet(n = n1_sam, a0 * pi0)
  otu_table_sim <- rbind(otu_table_sim_0, otu_table_sim_1)
  otu_table_sim[ ,spike.col.only] <- otu_table_sim[ ,spike.col.only] * exp(sign * alpha_log * Y)
  otu_table_sim[ ,spike.confounder.both] <- otu_table_sim[ ,spike.confounder.both] * exp(sign * alpha_log * Y) * exp(gamma_log * C) 
  otu_table_sim[ ,confounder.col.only] <- otu_table_sim[ ,confounder.col.only] * exp(gamma_log * C) 
  otu_table_sim <- otu_table_sim/rowSums(otu_table_sim)
  otu_table_sim_count <- array(0, dim = c(n_sam, n_otus))
  for (i in 1:n_sam) {
    otu_table_sim_count[i, ] <- rmultinom(1, library_size[i], otu_table_sim[i, ])
  }
  otu_table_sim <- otu_table_sim_count
  freq_table_sim <- otu_table_sim/library_size
  
  return(list(otu_table_sim = otu_table_sim, freq_table_sim = freq_table_sim, Y = Y, C = C, B = B, BB_t = BB_t))
}



