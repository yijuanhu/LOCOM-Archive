# ----------------------------
# Binary Setting Simulation
# ----------------------------
library(dirmult)
library(Rcpp)
library(RcppArmadillo)
library(R.utils)
library(metap)
library(permute)
source("utils.R")
source("LOCOM_fun.R")
sourceCpp("LOCOM.cpp")

causal.type <- 2    # simulation scenario
library.mu <- 10000 # mean of library size
disp <- 0.02        # dispersion parameter
n.sam <- 100        # total sample size
beta <- 0.4          # effect size 
freq.thres <- 0     # frequency threshold
censor.thres <- 0.8 # presence/absence threshold
ss <- 3             
library.sd = library.mu/ss # standard error in library size 
lib.sizer.lower = 2000     # lower bound for library size
fdr.target <- 0.2 # nominal fdr value

n.sim <- 5
otumat <- array(0, dim = c(n.sim, 5))
p.global.mat <- rep(0, n.sim)
for (i.seed in 1:n.sim) {
  cat("i.seed",i.seed,"\n")
  
  # -----------------------------
  # Simulate Data
  # -----------------------------
  simData <- SimulateDataPLNM(causal_type = causal.type,
                              beta = beta,
                              n_sam = n.sam, 
                              library_mu = library.mu, 
                              library_sd = library.sd, 
                              lib_sizer_lower = lib.sizer.lower, 
                              i_seed = i.seed)
  
  otu.table.sim <- simData$otu.table.sim
  freq.table.sim <- simData$freq.table.sim
  Y <- simData$Y
  causal.otus.sim <- simData$causal.otus.sim
  non.causal.otus.sim <- setdiff(c(1:ncol(otu.table.sim)), causal.otus.sim)
  
  # -----------------------------
  # Filter Data
  # -----------------------------
  filterData <- filterOTU(otu.table = otu.table.sim, freq.table = freq.table.sim, refer.col = 100, freq.thres = freq.thres, censor.thres = censor.thres, eps = 1)
  otu.table.sim.filter <- filterData$otu.table.filter
  refer.col <- filterData$refer.col
  otuname <- filterData$otuname
  filter.idx <- filterData$filter.idx
  censoring.rate <- filterData$censoring.rate
  causal.otus.sim.filter <- causal.otus.sim[!causal.otus.sim %in% filter.idx]
  non.causal.otus.sim.filter <- non.causal.otus.sim[!non.causal.otus.sim %in% filter.idx]
  cat("number of causal otu:", length(causal.otus.sim.filter), "\n") 
  
  # ------------------------------
  # Fit LOCOM
  # ------------------------------
  res <- locom(otu.table = otu.table.sim.filter, Y = Y, C = NULL, ref.otu = refer.col, fdr.nominal = fdr.target, seed = NULL, n.perm.max = 50000, n.rej.stop = 100, n.cores = 4)			   
  
  # ------------------------------
  # Summary results
  # ------------------------------
  res.summary <- summarize_otu_results(otuname = colnames(otu.table.sim.filter),
                                       qvalue = res$q.otu,
                                       causal.otus = causal.otus.sim.filter,
                                       non.causal.otus = non.causal.otus.sim.filter,
                                       fdr.target = fdr.target)
  
  
  n.otu <-  res.summary$n.otu
  sen.otu <-  res.summary$sen
  sep.otu <-  res.summary$sep
  fdr.otu <-  res.summary$fdr
  include <- as.numeric(100 %in% res.summary$otu.detected) #whether reference otu is included or not
  
  otumat[i.seed, ] <- c(n.otu, sen.otu, sep.otu, fdr.otu, include)
  p.global.mat[i.seed] <- res$p.global
}
