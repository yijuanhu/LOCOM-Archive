# ----------------------------
# Binary Setting Simulation
# ----------------------------
library(dirmult)
library(Rcpp)
library(RcppArmadillo)
library(R.utils)
library(metap)
library(permute)
source("utils.R")
source("LOCOM_fun.R")
sourceCpp("LOCOM.cpp")

causal.type <- 1    # simulation scenario
library.mu <- 10000 # mean of library size
disp <- 0.02        # dispersion parameter
n.sam <- 100        # total sample size
alpha <- 3          # effect size 
freq.thres <- 0     # frequency threshold
censor.thres <- 0.8 # presence/absence threshold
ss <- 3             
library.sd = library.mu/ss # standard error in library size 
lib.sizer.lower = 2000     # lower bound for library size
fdr.target <- 0.2 # nominal fdr value

n.sim <- 5
otumat <- array(0, dim = c(n.sim, 5))
p.global.mat <- rep(0, n.sim)
for (i.seed in 1:n.sim) {
  cat("i.seed",i.seed,"\n")
 
  # ----------------------------
  # Set frequency value
  # ----------------------------
  pi <- read.table("input_throat/fit_dirmult_pi.txt", header=FALSE, as.is=TRUE)[,1]
  n.otus = length(pi)

  # ----------------------------
  # causal type specification
  # ----------------------------
  if(causal.type == 1){
    random.col <- c(which(pi >= 0.005))[c(1:20)]
    spike.col <- random.col
  }

  if(causal.type == 2){
    random.col <- order(pi, decreasing = TRUE)[1:5]
    spike.col <- random.col
  }
  
  if(causal.type == 3){
    set.seed(0)
    random.col <- sort(sample(1:856, 500))
    spike.col <- random.col  
  }

  if(causal.type == 4){
    random.col <- c(which(pi >= 0.001 & pi <= 0.002))[c(1:20)]
    spike.col <- random.col 
  }

  causal.otus.sim = c(spike.col)
  n.otus.causal.sim = length(causal.otus.sim)
  non.causal.otus.sim = setdiff(1:n.otus, causal.otus.sim)
  n.otus.noncausal.sim = length(non.causal.otus.sim)

  # -----------------------------
  # Simulate Data
  # -----------------------------
  simData <- SimulateData(otu.freq = pi, 
                         spike.col.only = spike.col, 
                         spike.confounder.both = NULL,
                         confounder.col.only = NULL,
                         alpha = alpha, 
                         gamma = NULL,
                         library.mu = library.mu, 
                         library.sd = library.sd, 
                         lib.sizer.lower = lib.sizer.lower, 
                         disp = disp, 
                         n.sam = n.sam, 
                         trait = "Bin",
                         frac = 0.5, 
                         dist = "unif",
                         rho = 0.2,
                         causal.type = causal.type,
                         seed = i.seed)
  
  otu.table.sim <- simData$otu.table.sim
  freq.table.sim <- simData$freq.table.sim
  Y <- simData$Y
  
  # -----------------------------
  # Filter Data
  # -----------------------------
  colnames(otu.table.sim) <- c(1:ncol(otu.table.sim))
  filterData <- filterOTU(otu.table = otu.table.sim, freq.table = freq.table.sim, refer.col = 468, freq.thres = freq.thres, censor.thres = censor.thres, eps = 1)
  otu.table.sim.filter <- filterData$otu.table.filter
  refer.col <- filterData$refer.col
  otuname <- filterData$otuname
  filter.idx <- filterData$filter.idx
  censoring.rate <- filterData$censoring.rate
  causal.otus.sim.filter <- causal.otus.sim[!causal.otus.sim %in% filter.idx]
  non.causal.otus.sim.filter <- non.causal.otus.sim[!non.causal.otus.sim %in% filter.idx]
  cat("number of causal otu:", length(causal.otus.sim.filter), "\n") 
  
  # ------------------------------
  # Fit LOCOM
  # ------------------------------
  res <- locom(otu.table = otu.table.sim.filter, Y = Y, C = NULL, ref.otu = refer.col, fdr.nominal = fdr.target, seed = NULL, n.perm.max = 50000, n.rej.stop = 100, n.cores = 1)			   
  
  # ------------------------------
  # Summary results
  # ------------------------------
  res.summary <- summarize_otu_results(otuname = colnames(otu.table.sim.filter),
                  									   qvalue = res$q.otu,
                  									   causal.otus = causal.otus.sim.filter,
                  									   non.causal.otus = non.causal.otus.sim.filter,
                  									   fdr.target = fdr.target)

  
  n.otu <-  res.summary$n.otu
  sen.otu <-  res.summary$sen
  sep.otu <-  res.summary$sep
  fdr.otu <-  res.summary$fdr
  include <- as.numeric(468 %in% res.summary$otu.detected) #whether reference otu is included or not

  otumat[i.seed, ] <- c(n.otu, sen.otu, sep.otu, fdr.otu, include)
  p.global.mat[i.seed] <- res$p.global
}
