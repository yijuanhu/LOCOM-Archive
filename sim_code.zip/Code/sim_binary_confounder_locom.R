# ----------------------------
# Binary Trait & Binary Confounder Setting Simulation
# ----------------------------
library(dirmult)
library(Rcpp)
library(RcppArmadillo)
library(R.utils)
library(metap)
library(permute)
source("useful_function.R")
source("LOCOM_fun.R")
sourceCpp("LOCOM.cpp")

causal_type <- 1    # simulation scenario
library_mu <- 10000 # mean of library size
disp <- 0.02        # dispersion parameter
n_sam <- 100        # total sample size
alpha <- 3          # effect size 
gamma <- 2          # confounder effect size
freq_thres <- 0     # frequency threshold
censor_thres <- 0.8 # presence/absence threshold
ss <- 3             
library_sd = library_mu/ss # standard error in library size 
lib_sizer_lower = 2000     # lower bound for library size
fdr_target <- 0.2 # nominal fdr value

n_sim <- 5
otumat <- array(0, dim = c(n_sim, 5))
p_global_mat <- rep(0, n_sim)
for (i_seed in 1:n_sim) {
  cat("i_seed",i_seed,"\n")

  # ----------------------------
  # Set frequency value
  # ----------------------------
  pi <- read.table("input_throat/fit_dirmult_pi.txt", header=FALSE, as.is=TRUE)[,1]
  n_otus = length(pi)
  
  if(causal_type == 1){
	  spike.col.only <- which(pi >= 0.002)[1:10]
	  confounder.col.only <- which(pi >= 0.002)[21:30]
	  spike.confounder.both <- which(pi >= 0.002)[11:20]
  } 
  
  if(causal_type == 2){
  	spike.col.only <- order(pi, decreasing = TRUE)[1:3]
	  confounder.col.only <- order(pi, decreasing = TRUE)[31:33]
	  spike.confounder.both <- order(pi, decreasing = TRUE)[4:5]
  }
  
  causal_otus_sim = c(spike.col.only, spike.confounder.both)
  n_otus_causal_sim = length(causal_otus_sim)
  non_causal_otus_sim = setdiff(1:n_otus, causal_otus_sim)
  n_otus_noncausal_sim = length(non_causal_otus_sim)
  
  # -----------------------------
  # Simulate Data
  # -----------------------------
  simData <- Simulation_Binary_Confounder(otu_freq = pi, spike.col.only = spike.col.only, confounder.col.only = confounder.col.only, spike.confounder.both = spike.confounder.both, alpha = alpha, gamma = gamma, 
                                          library_mu = library_mu, library_sd = library_sd, lib_sizer_lower = lib_sizer_lower, disp = disp, n_sam = n_sam, frac = 0.5, rho = 0.2, seed = i_seed)
  otu_table_sim <- simData$otu_table_sim
  freq_table_sim <- simData$freq_table_sim
  Y <- simData$Y
  C <- simData$C
  B <- simData$B
  BB_t <- simData$BB_t
  
  # -----------------------------
  # Filter Data
  # -----------------------------
  colnames(otu_table_sim) <- c(1:ncol(otu_table_sim))
  filterData <- filter_otu(otu_table = otu_table_sim, freq_table = freq_table_sim, refer.col = 468, censor_thres = censor_thres, freq_thres = freq_thres, eps = 1)
  otu_table_sim_filter <-filterData$otu_table_filter
  refer.col <- filterData$refer.col
  otuname <- filterData$otuname
  filter.idx <- filterData$filter.idx
  censoring_rate <- filterData$censoring_rate
  causal_otus_sim_filter <- causal_otus_sim[!causal_otus_sim %in% filter.idx]
  non_causal_otus_sim_filter <- non_causal_otus_sim[!non_causal_otus_sim %in% filter.idx]
  cat("number of causal otu:", length(causal_otus_sim_filter), "\n") 
  
  # ------------------------------
  # Fit LOCOM: here we did not use locom function in the locom pacakge but use a locom function with a small variant. In this function, we can specify which otu to be used as the reference otu.
  # ------------------------------
  res <- locom(otu.table = otu_table_sim_filter, Y = Y, C = C,
               ref.otu = refer.col,
               fdr.nominal = fdr_target, seed = NULL,
               n.perm.max = 50000, n.rej.stop = 100, n.cores = 1)			   
  
  
  p_global_mat <- res$p.global
  res.summary <- summarize_otu_results(otuname = colnames(otu_table_sim_filter),
                                 qvalue = res$q.otu,
                                 causal_otus = causal_otus_sim,
                                 non_causal_otus  = non_causal_otus_sim,
                                 fdr_target = fdr_target)
  
  n_otu <-  res.summary$n_otu
  sen_otu <-  res.summary$sen
  sep_otu <-  res.summary$sep
  fdr_otu <-  res.summary$fdr
  include <- as.numeric(468 %in% res.summary$otu_detected) #whether reference otu is included or not
  
  otumat[i_seed, ] <- c(n_otu, sen_otu, sep_otu, fdr_otu, include)
  p_global_mat[i_seed] <- res$p.global
}
