#' A logistic regression model for testing differential abundance in compositional microbiome data (LOCOM)
#'
#' This function allows you to test
#' (1). whether any OTU (or taxon) is associated with the trait of interest with FDR control, based on the log ratio of relative abundances between pairs of taxa, and
#' (2). whehter the whole community is associated with the trait (a global test).
#' The tests accommodate both continuous and discrete (binary) traits and allows adjustment of confounders.
#'
#' This function uses a sequential stopping criterion (similar to that of Sandve et al. 2011) for the permutation procedure,
#' which stops when all taxon-level tests have either reached the pre-specified
#' number (default 100) of rejections or yielded a q-value (by the Benjamini-Hochberg [BH] procedure) that is below the
#' nominal FDR level (default 0.2). The permutation procedure is always terminated if a pre-specified maximum number (see description of \code{n.perm.max}) of
#' permutations have been generated. The global test is based on all permutation replicates when the procedure stops/terminates.
#'
#'
#' @param otu.table the OTU table (or taxa count table) in which the rows correspond to samples and the columns correspond to OTUs (taxa).
#' @param Y the trait of interest.
#' @param C the other (confounding) covariates to be adjusted.
#' @param fdr.nominal the nominal FDR. The default is 0.2.
#' @param seed a user-supplied integer seed for the random number generator in the
#'   permutation procedure. The default is NULL, which means that an integer seed will be
#'   generated internally and randomly. In either case, the integer seed will be stored
#'   in the output object in case the user wants to reproduce the permutation replicates.
#' @param n.perm.max the maximum number of permutations. The default is NULL, in which case \code{n.otu} * \code{n.rej.stop} * (1/\code{fdr.nominal})
#'   is used where \code{n.otu} is the total number of OTUs (that have non-zero counts in at least one sample).
#' @param n.rej.stop the minimum number of rejections (i.e., the permutation test
#'   statistic exceeds the observed test statistic) to obtain before stopping the permutation procedure. The
#'   default is 100.
#' @param n.cores the number of cores to be used for parallel computing. The default is 1.
#' @return A list consisting of
#' \itemize{
#'   \item effect.size - effect size at each OTU, i.e., beta_j,1 - median_j'=1,...J(beta_j',1)
#'   \item p.otu - p-values for OTU-specific tests
#'   \item q.otu - q-values (adjusted p-values by the BH procedure) for OTU-specific tests
#'   \item detected.otu - detected OTUs (using the column names of the OTU table) at the nominal FDR
#'   \item p.global - p-value for the global test
#'   \item n.perm.completed - number of permutations completed
#'   \item seed - the seed used to generate the permutation replicates
#' }
#' @export
#' @examples
#' # loading data
#'
#' data("throat.otu.table")
#' data("throat.meta")
#' data("throat.otu.taxonomy")
#'
#' otu.table <- data.matrix(throat.otu.table)
#'
#' Y <- ifelse(throat.meta$SmokingStatus == "NonSmoker", 0, 1)
#' C <- data.matrix(model.matrix(Y ~ throat.meta$Sex + throat.meta$AntibioticUsePast3Months_TimeFromAntibioticUsage - 1))[, -1]
#'
#' # filtering out three samples with antibiotic use
#'
#' filter.out.sam <- which(C[, 3] == 0)
#' otu.table.filter <- otu.table[-filter.out.sam,]
#' Y <- Y[-filter.out.sam]
#' C <- C[-filter.out.sam,]
#'
#' # filtering out rare OTUs
#'
#' prop.presence.thresh <- 0.2
#' prop.presence <- colMeans(otu.table.filter > 0)
#' filter.out.otu <- which(prop.presence < prop.presence.thresh)
#' if (length(filter.out.otu) > 0) {
#'     otu.table.filter <- otu.table.filter[, -filter.out.otu]
#'     prop.presence <- prop.presence[-filter.out.otu]
#' }
#'
#' # running locom
#' 
#' res <- locom(otu.table = otu.table.filter, Y = Y, C = C[, 1], fdr.nominal = 0.1, seed = 1, n.cores = 4)
#'
#' # summarizing results
#' # ordering the detected OTUs by their p-values. If no OTU is detected, we can still provide a summary table for
#' # the top (e.g., 10) OTUs by re-defining o = order(res$p.otu)[1:10]
#'
#' w <- match(res$detected.otu, colnames(res$p.otu))
#' o <- w[order(res$p.otu[w])]
#'
#' summary.table <- data.frame(otu.name = colnames(res$p.otu)[o],
#'                   mean.freq = colMeans(otu.table.filter/rowSums(otu.table.filter))[o],
#'                   prop.presence = prop.presence[o],
#'                   p.value = signif(res$p.otu[o], 3),
#'                   q.value = signif(res$q.otu[o], 3),
#'                   effect.size = signif(res$effect.size[o], 3),
#'                   otu.tax = throat.otu.taxonomy[as.numeric(colnames(res$p.otu)[o]) + 1],
#'                   row.names = NULL)
#' summary.table
locom <- function(otu.table, Y, C = NULL,
                  fdr.nominal = 0.2, seed = NULL,
                  n.perm.max = NULL, n.rej.stop = 100, n.cores = 1){
    
    # remove zero OTUs
    w = which(colSums(abs(otu.table))>0)
    if (length(w) < ncol(otu.table)) {
        warning(paste(ncol(otu.table)-length(w), 'OTU(s) with zero counts in all samples are removed', sep=" "))
        otu.table = otu.table[,w,drop=FALSE]
    }
    
    n.otus <- ncol(otu.table)
    
    if (is.null(n.perm.max)) {
        n.perm.max = n.otus * n.rej.stop * (1/fdr.nominal)
    }
    
    if (is.null(seed)) {
        seed = sample(1:10^6, 1)
    }
    
    weight.type <- 1
    bias.correction.thresh <- 0.4
    n.perm.block <- 1000
    
    prop.presence <- colMeans(otu.table>0)

    # ----------------------
    # Reference OTU
    # ----------------------
    
    mean.freq <- colMeans(otu.table/rowSums(otu.table))
    ref.otu <- which.max(mean.freq)
    
    # Zeros in the reference OTU
    
    pseudo.count.ref <- 1
    otu.table[which(otu.table[,ref.otu]==0), ref.otu] <- pseudo.count.ref
    
    
    # ----------------------
    # Weights in GEE
    # ----------------------
    
    if (weight.type == 1) {
        weight = (otu.table + otu.table[,ref.otu])
    } else if (weight.type == 2) {
        weight = (otu.table + otu.table[,ref.otu]) / rowSums(otu.table)
    }
    
    # -----------------------
    # Observed statistics
    # -----------------------
    
    if (is.null(C) == TRUE) {
        X <- cbind(1, Y)
    } else {
        X <- cbind(1, Y, C)
        Yr <- resid(lm(Y ~ C))
    }
    
    n.X <- ncol(X)
    XX <- CalculateXX(X)
    
    freq.table.ref <- otu.table/(otu.table + otu.table[,ref.otu])
    
    res.obs <- Newton(freq_table  = freq.table.ref, X = X, XX = XX,
                      W_init = array(0, dim = c(n.X, n.otus)),
                      weight = weight,
                      tol = 1e-6, iter_max = 50,
                      bias_correction = TRUE, model_based_var = TRUE,
                      prop_presence = prop.presence,
                      bias_correction_thresh = bias.correction.thresh)
    
    beta <- res.obs$W[2,]
    beta <- beta - median(beta)
    
    if (is.null(C) == TRUE){
        beta.other.cov <- res.obs$W[1,]
    } else {
        beta.other.cov <- res.obs$W[c(1,3:n.X),]
    }
    
    # -----------------------
    # Permutation
    # -----------------------
    
    beta.perm <- array(NA, dim = c(n.perm.max, n.otus))
    
    n.otu.left <- rep(0, n.otus)
    n.otu.right <- rep(0, n.otus)
    
    n.perm.completed <- 0
    n.block <- n.perm.max/n.perm.block
    

    set.seed(seed)
    n.sam <- nrow(otu.table)
    for(i.block in 1:n.block){
        
        perm.mat <- shuffleSet(n.sam, n.perm.block)
        perm.mat <- t(perm.mat - 1)
        
        parallel.perm <- function(i) {
            # Permutation(freq_table  = freq.table.ref, X = X,
            #                        W_init = rbind(0.5*beta.other.cov, 0),
            #                        weight = weight,
            #                        tol = 1e-6, iter_max = 50,
            #                        bias_correction = TRUE, model_based_var = TRUE,
            #                        N_perm = n.perm.block/n.cores, init_seed = seed + i.block * n.cores + i - 1,
            #                        prop_presence = prop.presence,
            #                        bias_correction_thresh = bias.correction.thresh)$W
            
            perm.mat.sub <- perm.mat[, (i*n.perm.block/n.cores + 1): ((i+1)*n.perm.block/n.cores)]
            PermutationParallel(freq_table  = freq.table.ref, X = X,
                                W_init = rbind(0.5*beta.other.cov, 0),
                                weight = weight,
                                tol = 1e-6, iter_max = 50,
                                bias_correction = TRUE, model_based_var = TRUE,
                                perm = perm.mat.sub,
                                prop_presence = prop.presence,
                                bias_correction_thresh = bias.correction.thresh)$W
        }
        
        parallel.perm.adj <- function(i) {
            # PermutationAdj(freq_table = freq.table.ref, X = X, Yr = Yr,
            #                           W_init = rbind(0.75*beta.other.cov[1,], 0, 0.75*beta.other.cov[2:(n.X-1),]),
            #                           weight = weight,
            #                           tol = 1e-6, iter_max = 50,
            #                           bias_correction = TRUE, model_based_var = TRUE,
            #                           N_perm = n.perm.block/n.cores, init_seed = seed + i.block * n.cores + i - 1,
            #                           prop_presence = prop.presence,
            #                           bias_correction_thresh = bias.correction.thresh)$W
            
            perm.mat.sub <- perm.mat[, (i*n.perm.block/n.cores + 1): ((i+1)*n.perm.block/n.cores)]
            PermutationAdjParallel(freq_table = freq.table.ref, X = X, Yr = Yr,
                           W_init = rbind(0.75*beta.other.cov[1,], 0, 0.75*beta.other.cov[2:(n.X-1),]),
                           weight = weight,
                           tol = 1e-6, iter_max = 50,
                           bias_correction = TRUE, model_based_var = TRUE,
                           perm = perm.mat.sub,
                           prop_presence = prop.presence,
                           bias_correction_thresh = bias.correction.thresh)$W
        }
        
        cat("permutations:", n.perm.completed+1, "\n")
        
        
        if (n.cores > 1) {

            if (Sys.info()[['sysname']] == 'Windows') {
                # registerDoParallel(n.cores)
                # cl <- makeCluster(n.cores, type="FORK")
                # parallel.stat <- parLapply(cl, 1:n.perm.block, parallel.perm, fit.res$x, perm, low, up, resid.dist, ndf, adjust.for.confounders)
                # stopCluster(cl)
                if (is.null(C) == TRUE) {
                    parallel.stat = bplapply(0:(n.cores - 1), parallel.perm, BPPARAM = MulticoreParam(workers=n.cores))
                } else {
                    parallel.stat = bplapply(0:(n.cores - 1), parallel.perm.adj, BPPARAM = MulticoreParam(workers=n.cores))
                }
            } else {
                if (is.null(C) == TRUE) {
                    parallel.stat = mclapply(0:(n.cores - 1), parallel.perm, mc.cores = n.cores)
                } else {
                    parallel.stat = mclapply(0:(n.cores - 1), parallel.perm.adj, mc.cores = n.cores)
                }
                
            }
            parallel.stat <- do.call(rbind, parallel.stat)
            res.perm <- list()
            res.perm[["W"]] <- parallel.stat
            
        } else {
            
            if (is.null(C) == TRUE) {
                res.perm <- PermutationParallel(freq_table = freq.table.ref, X = X,
                                        W_init = rbind(0.5*beta.other.cov, 0),
                                        weight = weight,
                                        tol = 1e-6, iter_max = 50,
                                        bias_correction = TRUE, model_based_var = TRUE,
                                        perm = perm.mat,
                                        #N_perm = n.perm.block, init_seed = seed + i.block - 1,
                                        prop_presence = prop.presence,
                                        bias_correction_thresh = bias.correction.thresh)
            } else {
                res.perm <- PermutationAdjParallel(freq_table = freq.table.ref, X = X, Yr = Yr,
                                           W_init = rbind(0.75*beta.other.cov[1,], 0, 0.75*beta.other.cov[2:(n.X-1),]),
                                           weight = weight,
                                           tol = 1e-6, iter_max = 50,
                                           bias_correction = TRUE, model_based_var = TRUE,
                                           perm = perm.mat,
                                           #N_perm = n.perm.block, init_seed = seed + i.block - 1,
                                           prop_presence = prop.presence,
                                           bias_correction_thresh = bias.correction.thresh)
            }
        }
        
        
        n.perm.completed <- i.block*n.perm.block
        n.perm.completed.inv <- 1 / (n.perm.completed+1)
        w <- ((i.block-1)*n.perm.block+1):n.perm.completed
        
        beta.perm[w,] <- res.perm$W
        beta.perm[w,] <- beta.perm[w,] - apply(beta.perm[w,], 1, median)
        
        n.otu.left <- n.otu.left + rowSums(beta>=t(beta.perm[w,]))
        n.otu.right <- n.otu.right + rowSums(beta<=t(beta.perm[w,]))
        n.otu <- 2*pmin(n.otu.left+1, n.otu.right+1)
        p.otu <- n.otu * n.perm.completed.inv
        q.otu <- .fdr.Sandev(p.otu)
        
        if (all(q.otu <= fdr.nominal | n.otu >= n.rej.stop)) break
        
    } # permutation
    
    detected.otu <- colnames(otu.table)[which(q.otu < fdr.nominal)]
    
    # ------------------------
    # Global p-value
    # ------------------------
    
    beta.all <- rbind(beta, beta.perm)
    
    p.otu1 <- apply( beta.all, 2, function(x) 0.5*(2*pmin(rank(x), n.perm.completed +2-rank(x))*2-3)*n.perm.completed.inv )
    
    stat.global <- rowSums(1/p.otu1)
    p.global <- (sum(stat.global[1] <= stat.global[-1]) + 1) * n.perm.completed.inv
    
    
    otu.names <- colnames(otu.table)
    beta <- matrix(beta, nrow = 1)
    p.otu <- matrix(p.otu, nrow = 1)
    q.otu <- matrix(q.otu, nrow = 1)
    colnames(beta) <- otu.names
    colnames(p.otu) <- otu.names
    colnames(q.otu) <- otu.names
    
    
    return(list(effect.size = beta,
                p.otu = p.otu,
                q.otu = q.otu,
                detected.otu = detected.otu,
                p.global = p.global,
                n.perm.completed = n.perm.completed,
                seed = seed))
    
} # locom


.fdr.Sandev = function(p.otu) {
    m = length(p.otu)
    p.otu.sort = sort(p.otu)
    n.otu.detected = seq(1, m)
    pi0 = min(1, 2/m*sum(p.otu))

    qval.sort = m * pi0 * p.otu.sort / n.otu.detected
    j.min.q = 1
    while (j.min.q < m) {
        min.q = min( qval.sort[j.min.q:m] )
        new.j.min.q = (j.min.q-1) + max( which(qval.sort[j.min.q:m]==min.q) )
        qval.sort[j.min.q:new.j.min.q] = qval.sort[new.j.min.q]
        j.min.q = new.j.min.q+1
    }
    mat = match(p.otu, p.otu.sort)
    qval.orig = qval.sort[mat]
    results = qval.orig

    return(results)

} # fdr.Sandev

# old version
# locom <- function(otu.table, Y, C = NULL,
#                   ref.otu = NULL, fdr.nominal = 0.2, seed = NULL,
#                   n.perm.max = NULL, n.rej.stop= 100){
#     
#     # remove zero OTUs
#     w = which(colSums(abs(otu.table))>0)
#     if (length(w) < ncol(otu.table)) {
#         warning(paste(ncol(otu.table)-length(w), 'OTU(s) with zero counts in all samples are removed', sep=" "))
#         otu.table = otu.table[,w,drop=FALSE]
#     }
#     
#     n.otu <- ncol(otu.table)
#     
#     if (is.null(n.perm.max)) {
#         n.perm.max = n.otu * n.rej.stop * (1/fdr.nominal)
#     }
#     
#     if (is.null(seed)) {
#         seed = sample(1:10^6, 1)
#     }
#     
#     weight.type <- 1
#     bias.correction.thresh <- 0.4
#     n.perm.block <- 1000
#     
#     prop.presence <- colMeans(otu.table>0)
#     
#     
#     # ----------------------
#     # Reference OTU
#     # ----------------------
#     
#     if (is.null(ref.otu)) {
#         mean.freq <- colMeans(otu.table/rowSums(otu.table))
#         ref.otu <- which.max(mean.freq)
#     }
#     
#     # Zeros in the reference OTU
#     
#     pseudo.count.ref <- 1
#     otu.table[which(otu.table[,ref.otu]==0), ref.otu] <- pseudo.count.ref
#     
#     
#     # ----------------------
#     # Weights in GEE
#     # ----------------------
#     
#     if (weight.type == 1) {
#         weight = (otu.table + otu.table[,ref.otu])
#     } else if (weight.type == 2) {
#         weight = (otu.table + otu.table[,ref.otu]) / rowSums(otu.table)
#     }
#     
#     # -----------------------
#     # Observed statistics
#     # -----------------------
#     
#     if (is.null(C) == TRUE) {
#         X <- cbind(1, Y)
#     } else {
#         X <- cbind(1, Y, C)
#         Yr <- resid(lm(Y ~ C))
#     }
#     
#     n.X <- ncol(X)
#     XX <- CalculateXX(X)
#     
#     freq.table.ref <- otu.table/(otu.table + otu.table[,ref.otu])
#     
#     res.obs <- Newton(freq_table  = freq.table.ref, X = X, XX = XX,
#                       W_init = array(0, dim = c(n.X, n.otu)),
#                       weight = weight,
#                       tol = 1e-6, iter_max = 50,
#                       bias_correction = TRUE, model_based_var = TRUE,
#                       prop_presence = prop.presence,
#                       bias_correction_thresh = bias.correction.thresh)
#     
#     beta <- res.obs$W[2,]
#     beta <- beta - median(beta)
#     
#     if (is.null(C) == TRUE){
#         beta.other.cov <- res.obs$W[1,]
#     } else {
#         beta.other.cov <- res.obs$W[c(1,3:n.X),]
#     }
#     
#     # -----------------------
#     # Permutation
#     # -----------------------
#     
#     beta.perm <- array(NA, dim = c(n.perm.max, n.otu))
#     
#     n.otu.left <- rep(0, n.otu)
#     n.otu.right <- rep(0, n.otu)
#     
#     n.perm.completed <- 0
#     n.block <- n.perm.max/n.perm.block
#     
#     
#     
#     
#     for(i.block in 1:n.block){
#         
#         cat("permutations:", n.perm.completed+1, "\n")
#         
#         if (is.null(C) == TRUE) {
#             res.perm <- Permutation(freq_table = freq.table.ref, X = X,
#                                     W_init = rbind(0.5*beta.other.cov, 0),
#                                     weight = weight,
#                                     tol = 1e-6, iter_max = 50,
#                                     bias_correction = TRUE, model_based_var = TRUE,
#                                     N_perm = n.perm.block, init_seed = seed + i.block - 1,
#                                     prop_presence = prop.presence,
#                                     bias_correction_thresh = bias.correction.thresh)
#             
#             
#         } else {
#             res.perm <- PermutationAdj(freq_table = freq.table.ref, X = X, Yr = Yr,
#                                        W_init = rbind(0.75*beta.other.cov[1,], 0, 0.75*beta.other.cov[2:(n.X-1),]),
#                                        weight = weight,
#                                        tol = 1e-6, iter_max = 50,
#                                        bias_correction = TRUE, model_based_var = TRUE,
#                                        N_perm = n.perm.block, init_seed = seed + i.block - 1,
#                                        prop_presence = prop.presence,
#                                        bias_correction_thresh = bias.correction.thresh)
#         }
#         
#         n.perm.completed <- i.block*n.perm.block
#         n.perm.completed.inv <- 1 / (n.perm.completed+1)
#         w <- ((i.block-1)*n.perm.block+1):n.perm.completed
#         
#         beta.perm[w,] <- res.perm$W
#         beta.perm[w,] <- beta.perm[w,] - apply(beta.perm[w,], 1, median)
#         
#         n.otu.left <- n.otu.left + rowSums(beta>=t(beta.perm[w,]))
#         n.otu.right <- n.otu.right + rowSums(beta<=t(beta.perm[w,]))
#         n.otu <- 2*pmin(n.otu.left+1, n.otu.right+1)
#         p.otu <- n.otu * n.perm.completed.inv
#         q.otu <- .fdr.Sandev(p.otu)
#         
#         if (all(q.otu <= fdr.nominal | n.otu >= n.rej.stop)) break
#         
#     } # permutation
#     
#     detected.otu <- colnames(otu.table)[which(q.otu < fdr.nominal)]
#     
#     # ------------------------
#     # Global p-value
#     # ------------------------
#     
#     beta.all <- rbind(beta, beta.perm)
#     
#     p.otu1 <- apply( beta.all, 2, function(x) 0.5*(2*pmin(rank(x), n.perm.completed +2-rank(x))*2-3)*n.perm.completed.inv )
#     
#     stat.global <- rowSums(1/p.otu1)
#     p.global <- (sum(stat.global[1] <= stat.global[-1]) + 1) * n.perm.completed.inv
#     
#     
#     otu.names <- colnames(otu.table)
#     beta <- matrix(beta, nrow = 1)
#     p.otu <- matrix(p.otu, nrow = 1)
#     q.otu <- matrix(q.otu, nrow = 1)
#     colnames(beta) <- otu.names
#     colnames(p.otu) <- otu.names
#     colnames(q.otu) <- otu.names
#     
#     
#     return(list(effect.size = beta,
#                 p.otu = p.otu,
#                 q.otu = q.otu,
#                 detected.otu = detected.otu,
#                 p.global = p.global,
#                 n.perm.completed = n.perm.completed,
#                 seed = seed))
#     
# } # locom
