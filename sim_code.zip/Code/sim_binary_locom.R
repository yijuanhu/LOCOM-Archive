# ----------------------------
# Binary Setting Simulation
# ----------------------------
library(dirmult)
library(Rcpp)
library(RcppArmadillo)
library(R.utils)
library(metap)
library(permute)
source("useful_function.R")
source("LOCOM_fun.R")
sourceCpp("LOCOM.cpp")

causal_type <- 1    # simulation scenario
library_mu <- 10000 # mean of library size
disp <- 0.02        # dispersion parameter
n_sam <- 100        # total sample size
alpha <- 3          # effect size 
freq_thres <- 0     # frequency threshold
censor_thres <- 0.8 # presence/absence threshold
ss <- 3             
library_sd = library_mu/ss # standard error in library size 
lib_sizer_lower = 2000     # lower bound for library size
fdr_target <- 0.2 # nominal fdr value

n_sim <- 5
otumat <- array(0, dim = c(n_sim, 5))
p_global_mat <- rep(0, n_sim)
for (i_seed in 1:n_sim) {
  cat("i_seed",i_seed,"\n")
 
  # ----------------------------
  # Set frequency value
  # ----------------------------
  pi <- read.table("input_throat/fit_dirmult_pi.txt", header=FALSE, as.is=TRUE)[,1]
  n_otus = length(pi)

  # ----------------------------
  # causal type specification
  # ----------------------------
  if(causal_type == 1){
    random.col <- c(which(pi >= 0.005))[c(1:20)]
    spike.col <- random.col
  }

  if(causal_type == 2){
    random.col <- order(pi, decreasing = TRUE)[1:5]
    spike.col <- random.col
  }
  
  if(causal_type == 3){
    set.seed(0)
    random.col <- sort(sample(1:856, 500))
    spike.col <- random.col  
  }

  if(causal_type == 4){
    random.col <- c(which(pi >= 0.001 & pi <= 0.002))[c(1:20)]
    spike.col <- random.col 
  }

  causal_otus_sim = c(spike.col)
  n_otus_causal_sim = length(causal_otus_sim)
  non_causal_otus_sim = setdiff(1:n_otus, causal_otus_sim)
  n_otus_noncausal_sim = length(non_causal_otus_sim)

  # -----------------------------
  # Simulate Data
  # -----------------------------
  simData <- Simulation_Binary(otu_freq = pi, spike.col = spike.col, alpha = alpha, library_mu = library_mu, library_sd = library_sd, lib_sizer_lower = lib_sizer_lower, disp = disp, n_sam = n_sam, frac = 0.5, seed = i_seed)
  otu_table_sim <- simData$otu_table_sim
  freq_table_sim <- simData$freq_table_sim
  Y <- simData$Y
  B <- simData$B
  BB_t <- simData$BB_t

  # -----------------------------
  # Filter Data
  # -----------------------------
  colnames(otu_table_sim) <- c(1:ncol(otu_table_sim))
  filterData <- filter_otu(otu_table = otu_table_sim, freq_table = freq_table_sim, refer.col = 468, freq_thres = freq_thres, censor_thres = censor_thres, eps = 1)
  otu_table_sim_filter <- filterData$otu_table_filter
  refer.col <- filterData$refer.col
  otuname <- filterData$otuname
  filter.idx <- filterData$filter.idx
  censoring_rate <- filterData$censoring_rate
  causal_otus_sim_filter <- causal_otus_sim[!causal_otus_sim %in% filter.idx]
  non_causal_otus_sim_filter <- non_causal_otus_sim[!non_causal_otus_sim %in% filter.idx]
  cat("number of causal otu:", length(causal_otus_sim_filter), "\n") 
  
  # ------------------------------
  # Fit LOCOM: here we did not use locom function in the locom pacakge but use a locom function with a small variant. In this function, we can specify which otu to be used as the reference otu.
  # ------------------------------
  res <- locom(otu.table = otu_table_sim_filter, Y = Y, C = NULL, ref.otu = refer.col, fdr.nominal = fdr_target, seed = NULL, n.perm.max = 50000, n.rej.stop = 100, n.cores = 1)			   
  
  # ------------------------------
  # Summary results
  # ------------------------------
  res.summary <- summarize_otu_results(otuname = colnames(otu_table_sim_filter),
                  									   qvalue = res$q.otu,
                  									   causal_otus = causal_otus_sim_filter,
                  									   non_causal_otus = non_causal_otus_sim_filter,
                  									   fdr_target = fdr_target)

  
  n_otu <-  res.summary$n_otu
  sen_otu <-  res.summary$sen
  sep_otu <-  res.summary$sep
  fdr_otu <-  res.summary$fdr
  include <- as.numeric(468 %in% res.summary$otu_detected) #whether reference otu is included or not

  otumat[i_seed, ] <- c(n_otu, sen_otu, sep_otu, fdr_otu, include)
  p_global_mat[i_seed] <- res$p.global
}
