# -------------------------
# This script is used to compare six different methods: ANCOM; ALDEx2; WRENCH; DACOMP; Wilcox-Thres; Wilcox  
# -------------------------
library(ALDEx2)
library(Wrench)
library(dacomp)
library(exactRankTests)

Method_Comparsion_NoConfounder <- function(otu_table, otu_table_sim, filter.idx,  Y, fdr_target, method, 
                                           causal_otus_sim, n_otus_causal_sim, non_causal_otus_sim, n_otus_noncausal_sim, 
                                           perc = 0.9, median_SD_threshold = 1.3, filter = "ANCOM", ps.count = 1){
      # Args: otu_table: filtered otu_table
	    #       otu_table_sim: original otu_table
      #       filter.idx: filder index
      #       Y: trait
      #       fdr_tagert: fdr_target name
      #       method: method name		
      #       perc: parameter for DACOMP
      #       meidan_SD_threshold: parameter for DACOMP
      #       filter: filtering criterion, "ANCOM": default criterion in ANCOM	
      #       ps.count: pseudo count number
  
  if(filter!= "ANCOM"){
	if(method == "ANCOMBC"){
		#================Build a Phyloseq-Class Object from Scratch==================
		otu_mat <- t(otu_table_sim)
		rownames(otu_mat) = 1:nrow(otu_mat)
		colnames(otu_mat) = paste0("sample", 1:ncol(otu_mat))
		
		meta <- data.frame(group = Y,
						   row.names = paste0("sample", 1:ncol(otu_mat)),
						   stringsAsFactors = FALSE)
		
		tax_mat = matrix(sample(letters, 7 * nrow(otu_mat), replace = TRUE),
						 nrow = nrow(otu_mat), ncol = 7)
		rownames(tax_mat) = rownames(otu_mat)
		colnames(tax_mat) = c("Kingdom", "Phylum", "Class", "Order",
							  "Family", "Genus", "Species")
		OTU = otu_table(otu_mat, taxa_are_rows = TRUE)
		META = sample_data(meta)
		TAX = tax_table(tax_mat)
		physeq = phyloseq(OTU, META, TAX)
		#========================Run ANCOMBC Using a Real Data=======================
		out = ancombc(phyloseq = physeq, formula = "group",
					  p_adj_method = "holm", zero_cut = 0.80, lib_cut = 1000,
					  group = "group", struc_zero = TRUE, neg_lb = FALSE,
					  tol = 1e-5, max_iter = 100, conserve = TRUE,
					  alpha = 0.05, global = TRUE)
		
		otu.ancom = as.numeric(rownames(out$res$q_val)[which(out$res$q_val <= fdr_target)])
		(n_otu.ancom = length(otu.ancom))
		(sen.ancom = sum(otu.ancom %in% causal_otus_sim)/n_otus_causal_sim)
		(sep.ancom = 1- sum(otu.ancom %in% non_causal_otus_sim)/n_otus_noncausal_sim)
		(FDR.ancom = (n_otu.ancom - sum(otu.ancom %in% causal_otus_sim))/n_otu.ancom)
		
		n_otu <- n_otu.ancom
		sen <- sen.ancom
		sep <- sep.ancom	
		FDR <- FDR.ancom
	  }  
  
	  if(method == "ANCOM"){
  		otu_table_sim_ancom <- t(otu_table_sim)
  		colnames(otu_table_sim_ancom) <- paste("ID", c(1:ncol(otu_table_sim_ancom)), sep = "")
  		meta_data <- data.frame(Sample.ID = paste("ID", c(1:ncol(otu_table_sim_ancom)), sep = ""), Y = Y) #, C = rep(0, nrow(otu_table_sim)))    
  		
  		feature_table = otu_table_sim_ancom; sample_var = "Sample.ID"; group_var = NULL
  		out_cut = 0.05; zero_cut = 0.80; lib_cut = 1000; neg_lb = FALSE
  		prepro = feature_table_pre_process(feature_table, meta_data, sample_var, group_var, out_cut, zero_cut, lib_cut, neg_lb)
  		feature_table = prepro$feature_table 
  		meta_data = prepro$meta_data # Preprocessed metadata
  		struc_zero = prepro$structure_zeros # Structural zero info
  		
  		main_var = "Y"; p_adj_method = "BH";
  		adj_formula = NULL; rand_formula = NULL
  		res.ancom = ANCOM(feature_table, meta_data, struc_zero, main_var, p_adj_method, 
  					fdr_target, adj_formula, rand_formula)
  		
  		otu.ancom = as.numeric(as.character(res.ancom$out$taxa_id[which(res.ancom$out[, paste("detected_", perc, sep = "")]== TRUE)])) # choose 0.9 percentile as cutoff
  		(n_otu.ancom = length(otu.ancom))
  		(sen.ancom = sum(otu.ancom %in% causal_otus_sim)/n_otus_causal_sim)
  		(sep.ancom = 1- sum(otu.ancom %in% non_causal_otus_sim)/n_otus_noncausal_sim)
  		(FDR.ancom = (n_otu.ancom - sum(otu.ancom %in% causal_otus_sim))/n_otu.ancom)
  		
  		n_otu <- n_otu.ancom
  		sen <- sen.ancom
  		sep <- sep.ancom	
  		FDR <- FDR.ancom
	  } 
   } else {
      	if(method == "ANCOMBC"){
		#================Build a Phyloseq-Class Object from Scratch==================
		otu_mat <- t(otu_table_sim)
		rownames(otu_mat) = 1:nrow(otu_mat)
		colnames(otu_mat) = paste0("sample", 1:ncol(otu_mat))
		
		meta <- data.frame(group = Y,
						   row.names = paste0("sample", 1:ncol(otu_mat)),
						   stringsAsFactors = FALSE)
		
		tax_mat = matrix(sample(letters, 7 * nrow(otu_mat), replace = TRUE),
						 nrow = nrow(otu_mat), ncol = 7)
		rownames(tax_mat) = rownames(otu_mat)
		colnames(tax_mat) = c("Kingdom", "Phylum", "Class", "Order",
							  "Family", "Genus", "Species")
		OTU = otu_table(otu_mat, taxa_are_rows = TRUE)
		META = sample_data(meta)
		TAX = tax_table(tax_mat)
		physeq = phyloseq(OTU, META, TAX)
		#========================Run ANCOMBC Using a Real Data=======================
		out = ancombc(phyloseq = physeq, formula = "group",
					  p_adj_method = "holm", zero_cut = 0.90, lib_cut = 1000,
					  group = "group", struc_zero = TRUE, neg_lb = FALSE,
					  tol = 1e-5, max_iter = 100, conserve = TRUE,
					  alpha = 0.05, global = TRUE)
		
		otu.ancom = as.numeric(rownames(out$res$q_val)[which(out$res$q_val <= fdr_target)])
		(n_otu.ancom = length(otu.ancom))
		(sen.ancom = sum(otu.ancom %in% causal_otus_sim)/n_otus_causal_sim)
		(sep.ancom = 1- sum(otu.ancom %in% non_causal_otus_sim)/n_otus_noncausal_sim)
		(FDR.ancom = (n_otu.ancom - sum(otu.ancom %in% causal_otus_sim))/n_otu.ancom)
		
		n_otu <- n_otu.ancom
		sen <- sen.ancom
		sep <- sep.ancom	
		FDR <- FDR.ancom
	  }  
  
	  if(method == "ANCOM"){
  		otu_table_sim_ancom <- t(otu_table_sim)
  		colnames(otu_table_sim_ancom) <- paste("ID", c(1:ncol(otu_table_sim_ancom)), sep = "")
  		meta_data <- data.frame(Sample.ID = paste("ID", c(1:ncol(otu_table_sim_ancom)), sep = ""), Y = Y) #, C = rep(0, nrow(otu_table_sim)))    
  		
  		feature_table = otu_table_sim_ancom; sample_var = "Sample.ID"; group_var = NULL
  		out_cut = 0.05; zero_cut = 0.90; lib_cut = 1000; neg_lb = FALSE
  		prepro = feature_table_pre_process(feature_table, meta_data, sample_var, group_var, out_cut, zero_cut, lib_cut, neg_lb)
  		feature_table = prepro$feature_table 
  		meta_data = prepro$meta_data # Preprocessed metadata
  		struc_zero = prepro$structure_zeros # Structural zero info
  		
  		main_var = "Y"; p_adj_method = "BH";
  		adj_formula = NULL; rand_formula = NULL
  		res.ancom = ANCOM(feature_table, meta_data, struc_zero, main_var, p_adj_method, 
  					fdr_target, adj_formula, rand_formula)
  		
  		otu.ancom = as.numeric(as.character(res.ancom$out$taxa_id[which(res.ancom$out[, paste("detected_", perc, sep = "")]== TRUE)])) # choose 0.9 percentile as cutoff
  		(n_otu.ancom = length(otu.ancom))
  		(sen.ancom = sum(otu.ancom %in% causal_otus_sim)/n_otus_causal_sim)
  		(sep.ancom = 1- sum(otu.ancom %in% non_causal_otus_sim)/n_otus_noncausal_sim)
  		(FDR.ancom = (n_otu.ancom - sum(otu.ancom %in% causal_otus_sim))/n_otu.ancom)
  		
  		n_otu <- n_otu.ancom
  		sen <- sen.ancom
  		sep <- sep.ancom	
  		FDR <- FDR.ancom
	  } 
   }
  # -------------------
  # Method of ALDEx2
  # -------------------
  if(method == "ALDEx2") {
    if(length(unique(Y)) == 2){
      otu_table_aldex2 <- t(otu_table)
      conds <- ifelse(Y==0, "A", "B")
      x <- aldex.clr(otu_table_aldex2, conds, mc.samples=128, verbose=TRUE)
      x.tt <- aldex.ttest(x, paired.test=FALSE, hist.plot = FALSE)
      res.aldex2 <- data.frame(x.tt, stringsAsFactors=FALSE)
      if (nrow(res.aldex2) == nrow(otu_table_sim)) {
        otu.aldex2 <- sort(which(res.aldex2$we.eBH <= fdr_target))
      }else{
        old.we.eBH <- res.aldex2$we.eBH
        for (idx.i in 1:length(filter.idx)) {
          temp.we.eBH <- old.we.eBH
          new.we.eBH <- insert(temp.we.eBH, filter.idx[idx.i], 100)
          old.we.eBH <- new.we.eBH
        }
        otu.aldex2 <- sort(which(new.we.eBH <= fdr_target))
      }
    } else {
      otu_table_aldex2 <- t(otu_table)
      covariates <- data.frame("Y" = Y)
      mm <- model.matrix(~ Y, covariates)
      x <- aldex.clr(otu_table_aldex2, mm, mc.samples=128, verbose=TRUE)
      x.tt <- aldex.glm(x)
      res.aldex2 <- data.frame(x.tt, stringsAsFactors=FALSE)  
      if (nrow(res.aldex2) == nrow(otu_table_sim)) {
        otu.aldex2 <- sort(which(res.aldex2$model.Y.Pr...t...BH <= fdr_target)) # can also use wi.eBH (Wilcox test p-value after BH)
      }else{
        #idx <- which(rowSums(otu_table_sim_aldex2) == 0)
        old.we.eBH <- res.aldex2$model.Y.Pr...t...BH
        for (idx.i in 1:length(filter.idx)) {
          temp.we.eBH <- old.we.eBH
          new.we.eBH <- insert(temp.we.eBH, filter.idx[idx.i], 100)
          old.we.eBH <- new.we.eBH
        }
        otu.aldex2 <- sort(which(new.we.eBH <= fdr_target))
      }
    }
  
  
    (n_otu.aldex2 = length(otu.aldex2))
    (sen.aldex2 = sum(otu.aldex2 %in% causal_otus_sim)/n_otus_causal_sim)
    (sep.aldex2 = 1- sum(otu.aldex2 %in% non_causal_otus_sim)/n_otus_noncausal_sim)
    (FDR.aldex2 = (n_otu.aldex2 - sum(otu.aldex2 %in% causal_otus_sim))/n_otu.aldex2)
    
    n_otu <- n_otu.aldex2
    sen <- sen.aldex2
    sep <- sep.aldex2	
    FDR <- FDR.aldex2
  }
  
  # ---------------
  # DACOMP
  # ---------------
  if(method == "DACOMP"){
    result.selected.references = dacomp.select_references(
                                 X = otu_table,
                                 median_SD_threshold = median_SD_threshold, #APPLICATION SPECIFIC
                                 verbose = F)
    
    if(length(unique(Y)) == 2){
      res.damp = dacomp.test(X = otu_table, #counts data
                             y = Y, #phenotype in y argument
                             ind_reference_taxa = result.selected.references, 
                             test = DACOMP.TEST.NAME.WILCOXON, #constant, name of test
                             verbose = F,q = 0.05)
    } else {
      res.damp = dacomp.test(X = otu_table, #counts data
                             y = Y, #phenotype in y argument
                             ind_reference_taxa = result.selected.references, 
                             test = DACOMP.TEST.NAME.SPEARMAN, #constant, name of test
                             verbose = F,q = 0.05)
    }
    
    if (length(res.damp$p.values.test) == ncol(otu_table_sim)) {
      temp.q <- p.adjust(res.damp$p.values.test,method = 'BH')
      otu.damp <- sort(which(temp.q  <= fdr_target))
      (n_otu.damp = length(otu.damp))
      (sen.damp = sum(otu.damp %in% causal_otus_sim)/n_otus_causal_sim)
      (sep.damp = 1- sum(otu.damp %in% non_causal_otus_sim)/n_otus_noncausal_sim)
      (FDR.damp = (n_otu.damp - sum(otu.damp %in% causal_otus_sim))/n_otu.damp)
    } else{
      temp.q <- p.adjust(res.damp$p.values.test,method = 'BH')
      for (idx.i in 1:length(filter.idx)) {
        new.q <- insert(temp.q, filter.idx[idx.i], NA)
        temp.q <- new.q
      }
      otu.damp <- sort(which(temp.q  <= fdr_target))
      (n_otu.damp = length(otu.damp))
      (sen.damp = sum(otu.damp %in% causal_otus_sim)/n_otus_causal_sim)
      (sep.damp = 1- sum(otu.damp %in% non_causal_otus_sim)/n_otus_noncausal_sim)
      (FDR.damp = (n_otu.damp - sum(otu.damp %in% causal_otus_sim))/n_otu.damp)
    }
    n_otu <- n_otu.damp
    sen <- sen.damp
    sep <- sep.damp	
    FDR <- FDR.damp
  }
  
  # ------------
  # Wrench
  # ------------
  if(method == "WRENCH"){
    res.wrench <- wrench(t(otu_table), Y, z.adj = TRUE)
    res.wrench <- Wilcox(otu_table*res.wrench$nf, Y)
    
    if (length(res.wrench$adjust.pvalue) == ncol(otu_table_sim)) {
      otu.test= sort(which(res.wrench$adjust.pvalue <= fdr_target))
    } else{
      old.q <- res.wrench$adjust.pvalue
      for (idx.i in 1:length(filter.idx)) {
        temp.q <- old.q
        new.q <- insert(temp.q, filter.idx[idx.i], 100)
        old.q <- new.q
      }
      otu.test= sort(which(new.q <= fdr_target))
    }
    (n_otu.Wrench = length(otu.test))
    (sen.Wrench = sum(otu.test %in% causal_otus_sim)/n_otus_causal_sim)
    (sep.Wrench = 1- sum(otu.test %in% non_causal_otus_sim)/n_otus_noncausal_sim)
    (FDR.Wrench = (n_otu.Wrench - sum(otu.test %in% causal_otus_sim))/n_otu.Wrench)
    n_otu <- n_otu.Wrench
    sen <- sen.Wrench
    sep <- sep.Wrench
    FDR <- FDR.Wrench
  }
  # --------------
  # PS
  # --------------
  if(method == "PS"){
    otu_table_ps <- otu_table + ps.count
    otu_table_ps_alr <- log(otu_table_ps/otu_table_ps[,refer.col])
    res.ps <- Wilcox(otu_table_ps_alr, Y)
    if (length(res.ps$adjust.pvalue) == ncol(otu_table_sim)) {
      otu.test= sort(which(res.ps$adjust.pvalue <= fdr_target))
    } else{
      old.q <- res.ps$adjust.pvalue
      for (idx.i in 1:length(filter.idx)) {
        temp.q <- old.q
        new.q <- insert(temp.q, filter.idx[idx.i], 100)
        old.q <- new.q
      }
      otu.test= sort(which(new.q <= fdr_target))
    }
    (n_otu.ps = length(otu.test))
    (sen.ps = sum(otu.test %in% causal_otus_sim)/n_otus_causal_sim)
    (sep.ps = 1- sum(otu.test %in% non_causal_otus_sim)/n_otus_noncausal_sim)
    (FDR.ps = (n_otu.ps - sum(otu.test %in% causal_otus_sim))/n_otu.ps)
    n_otu <- n_otu.ps
    sen <- sen.ps
    sep <- sep.ps
    FDR <- FDR.ps
  }
  
  # --------------------
  # TSS
  # --------------------
  if(method == "TSS"){
    otu_table_tss <- otu_table/rowSums(otu_table)
    res.tss <- Wilcox(otu_table, Y)
    
    if (length(res.tss$adjust.pvalue) == ncol(otu_table_sim)) {
      otu.test= sort(which(res.tss$adjust.pvalue <= fdr_target))
    } else{
      old.q <- res.tss$adjust.pvalue
      for (idx.i in 1:length(filter.idx)) {
        temp.q <- old.q
        new.q <- insert(temp.q, filter.idx[idx.i], 100)
        old.q <- new.q
      }
      otu.test= sort(which(new.q <= fdr_target))
    }
    (n_otu.tss = length(otu.test))
    (sen.tss = sum(otu.test %in% causal_otus_sim)/n_otus_causal_sim)
    (sep.tss = 1- sum(otu.test %in% non_causal_otus_sim)/n_otus_noncausal_sim)
    (FDR.tss = (n_otu.tss - sum(otu.test %in% causal_otus_sim))/n_otu.tss)
    n_otu <- n_otu.tss
    sen <- sen.tss
    sep <- sep.tss
    FDR <- FDR.tss
  }
  
  return(list(n_otu = n_otu, sen = sen, sep = sep, FDR = FDR))
}
