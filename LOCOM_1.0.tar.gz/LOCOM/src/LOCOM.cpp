#include <RcppArmadillo.h>
#include <cmath>
//[[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;
using namespace arma;


// [[Rcpp::export]]
arma::cube CalculateXX(const arma::mat & X){
  int K = X.n_cols;
  int n_sam = X.n_rows;
  arma::cube XX(K, K, n_sam);
  for(int s=0;s < n_sam; s++){
    for(int i=0; i < K; i++){
      for(int j=i; j < K; j++){
        XX(i, j, s) = X(s, i) * X(s, j);
        XX(j, i, s) = XX(i, j, s);
      }
    }
  }
  return XX;
}

arma::cube CalculatePermX(const arma::cube & XX, const arma::mat & X, arma::vec z){
  int n_sam = XX.n_slices;
  int K = XX.n_rows;
  arma::cube XX_perm = XX;
  for(int s=0;s < n_sam; s++){
    XX_perm(0, 1, s) = z(s);
    XX_perm(1, 0, s) = z(s);
    XX_perm(1, 1, s) = z(s) * z(s);
    for(int j=2; j < K; j ++){
      XX_perm(1, j, s) = z(s) * X(s, j);
      XX_perm(j, 1, s) = XX_perm(1, j, s);
    }
  }
  return XX_perm;
}

void SetSeed(unsigned int seed) {
  Rcpp::Environment base_env("package:base");
  Rcpp::Function set_seed_r = base_env["set.seed"];
  set_seed_r(seed);
}


//' Solve Modified Estimation Equation using Quasi-Newton Algorithm
//'
//' This is a function to implement Quasi-Newton Algorithm to solve modified estimation equations.
//'
//'
//' @param freq_table frequency table
//' @param B  Design matrix of all samples
//' @param BB A cube saving B_iB_i^t for each sample
//' @param W_init Initial value of beta parameters
//' @param weight weight in the estimation equations
//' @param tol Stopping criterion. Default value is 1e-6.
//' @param iter_max Maximum iteration number

//' @examples
//' between(1:12, 7, 9)
//'
// [[Rcpp::export]]
List Newton(arma::mat freq_table, arma::mat X, arma::cube XX, arma::mat W_init, arma::mat weight,
            double tol, int iter_max,
            bool bias_correction, bool model_based_var, arma::vec prop_presence, double bias_correction_thresh) {

  int n_otus = freq_table.n_cols;
  int n_sam = freq_table.n_rows;
  int K = X.n_cols;

  arma::mat W_temp;
  arma::mat W_new;
  arma::mat W = W_init;
  arma::mat X_mat = X;
  arma::mat J_temp;
  arma::mat J_temp_1;
  arma::mat H_temp;
  arma::vec z;
  arma::vec u;
  arma::vec S;
  arma::vec delta(K, fill::zeros);
  arma::mat J(K, K, fill::zeros);
  arma::mat HH(K, K, fill::zeros);
  arma::mat Step;
  arma::mat SVar;
  arma::mat J_inv;
  arma::vec SVar_final(n_otus);
  arma::cube H(K, K, K, fill::zeros);


  int count;
  for(int j=0; j< n_otus; j++){
    W.col(j) = W_init.col(j);

    if(prop_presence(j) < bias_correction_thresh){
      for(int i=0; i<iter_max; i++){

        z = exp(X_mat * W.col(j));
        u = z / (1 + z);

        S = X_mat.t() * ( (freq_table.col(j) - u) % (weight.col(j)) ); // * means matrix multiplication; % means element-wise multiplication

        J_temp = -(u % (1-u)) % (weight.col(j));
        J_temp_1 = - J_temp % (1-2*u);

        J.fill(0);
        for(int i_sam=0; i_sam < n_sam; i_sam++){
          J = J + J_temp(i_sam) * XX.slice(i_sam);
        }
        J_inv = inv(J);

        //bias correction step begin
        delta.fill(0);
        for(int k=0; k < K;k++) {
          HH.fill(0);
          H_temp = J_temp_1 % X_mat.col(k);
          for(int i_sam=0; i_sam < n_sam; i_sam++){
            HH = HH + H_temp(i_sam) * XX.slice(i_sam);
          }
          delta(k) = delta(k) - trace(HH * J_inv);
        }
        S = S + delta * 0.5;
        ///////////////////////////////////////////////////////////////////////////////////////////////////

        //update procedure
        Step = J_inv * S;
        if(sum(abs(Step.col(0))) > 100){
         W.col(j).fill(0);
        } else {
        W.col(j) = W.col(j) - Step;
        }
        count = sum(abs(Step.col(0)) < tol);
        if(count == K){
          break;
        }
      }
    } else {
      for(int i=0; i<iter_max; i++){

        z = exp(X_mat * W.col(j));
        u = z / (1 + z);

        S = X_mat.t() * ( (freq_table.col(j) - u) % (weight.col(j)) ); // * means matrix multiplication; % means element-wise multiplication

        J_temp = -(u % (1-u)) % (weight.col(j));
        J_temp_1 = - J_temp % (1-2*u);

        J.fill(0);
        for(int i_sam=0; i_sam < n_sam; i_sam++){
          J = J + J_temp(i_sam) * XX.slice(i_sam);
        }
        J_inv = inv(J);
        ///////////////////////////////////////////////////////////////////////////////////////////////////

        //update procedure
        Step = J_inv * S;
        if(sum(abs(Step.col(0))) > 100){
          W.col(j).fill(0);
        } else {
        W.col(j) = W.col(j) - Step;
        }
        count = sum(abs(Step.col(0)) < tol);
        if(count == K){
          break;
        }
      }
    }

    SVar_final(j) = J_inv(1,1);

  }
  return  List::create(Named("W") = W, Named("SVar") = SVar_final);
}

//' Conduct Permutation in the case when there is no confounder
//'
//' This function conducts permutation in that case when there is no confounder. This permutation runs much faster
//' compared with the permutation in R.
//'
//' @param freq_table frequency table
//' @param B  Design matrix of all samples
//' @param BB A cube saving B_iB_i^t for each sample
//' @param W_init Initial value of beta parameters
//' @param weight weight in the estimation equations
//' @param tol Stopping criterion. Default value is 1e-6.
//' @param iter_max Maximum iteration number
//' @param N_perm Number of permutation
//' @param init_seed Initial seed for permutation

//' @examples
//' between(1:12, 7, 9)
//'
//' x <- rnorm(1e2)
//' x[between(x, -1, 1)]
// [[Rcpp::export]]
List Permutation(arma::mat freq_table, arma::mat X,
                 arma::mat W_init, arma::mat weight,
                 double tol, int iter_max,
                 bool bias_correction, bool model_based_var,
                 int N_perm,  int init_seed,
                 arma::vec prop_presence, double bias_correction_thresh) {
  int n_otus = freq_table.n_cols;
  int n_sam = freq_table.n_rows;
  arma::mat BR_est_temp(N_perm, n_otus); //save beta of trait information
  arma::mat VAR_est_temp(N_perm, n_otus); //save variance information
  arma::cube XX_t;
  arma::mat X_perm;
  List res;
  SetSeed(init_seed); //
  for(int n_perm=0; n_perm < N_perm; n_perm++){
    uvec o = randperm(n_sam); // generate permuation
    X_perm = X.rows(o);       // permute design matrix
    XX_t = CalculateXX(X_perm);
    List res =  Newton(freq_table, X_perm, XX_t, W_init, weight, tol, iter_max, bias_correction, model_based_var, prop_presence, bias_correction_thresh);
    arma::mat res_W = res["W"];
    arma::vec res_Var = res["SVar"];
    BR_est_temp.row(n_perm) = res_W.row(1);
    VAR_est_temp.row(n_perm) = res_Var.t();
  }

  return List::create(Named("W") = BR_est_temp, Named("VAR") = VAR_est_temp);
}

// [[Rcpp::export]]
List PermutationParallel(arma::mat freq_table, arma::mat X,
                         arma::mat W_init, arma::mat weight,
                         double tol, int iter_max,
                         bool bias_correction, bool model_based_var,
                         arma::umat perm,
                         arma::vec prop_presence, double bias_correction_thresh) {
  int n_otus = freq_table.n_cols;
  int n_sam = freq_table.n_rows;
  int N_perm = perm.n_cols; 
  arma::mat BR_est_temp(N_perm, n_otus); //save beta of trait information
  arma::mat VAR_est_temp(N_perm, n_otus); //save variance information
  arma::cube XX_t;
  arma::mat X_perm;
  
  for(int n_perm=0; n_perm < N_perm; n_perm++){
    uvec o = perm.col(n_perm);
    X_perm = X.rows(o);     
    XX_t = CalculateXX(X_perm);
    List res =  Newton(freq_table, X_perm, XX_t, W_init, weight, tol, iter_max, bias_correction, model_based_var, prop_presence, bias_correction_thresh);
    arma::mat res_W = res["W"];
    arma::vec res_Var = res["SVar"];
    BR_est_temp.row(n_perm) = res_W.row(1);
    VAR_est_temp.row(n_perm) = res_Var.t();
  }
  return List::create(Named("W") = BR_est_temp, Named("VAR") = VAR_est_temp);
}

//' Conduct Permutation in the case when there are confounders
//'
//' This function conducts permutation in that case when there are confounders. This permutation runs much faster
//' compared with the permutation in R.
//'
//' @param freq_table frequency table
//' @param z Residual of regressing trait on confounders
//' @param B  Design matrix of all samples
//' @param BB A cube saving B_iB_i^t for each sample
//' @param W_init Initial value of beta parameters
//' @param weight weight in the estimation equations
//' @param tol Stopping criterion. Default value is 1e-6.
//' @param iter_max Maximum iteration number
//' @param N_perm Number of permutation
//' @param init_seed Initial seed for permutation

//' @examples
//' between(1:12, 7, 9)
//'
//' x <- rnorm(1e2)
//' x[between(x, -1, 1)]
// [[Rcpp::export]]
List PermutationAdj(arma::mat freq_table, arma::vec Yr, arma::mat X,
                    arma::mat W_init, arma::mat weight,
                    double tol, int iter_max,
                    bool bias_correction, bool model_based_var,
                    int N_perm,  int init_seed,
                    arma::vec prop_presence, double bias_correction_thresh)  {

  int n_otus = freq_table.n_cols;
  int n_sam = freq_table.n_rows;
  int K = X.n_cols;

  arma::mat BR_est_temp(N_perm, n_otus); //save beta of trait information
  arma::mat VAR_est_temp(N_perm, n_otus); //save variance information
  arma::cube XX_t(K, K, n_sam);
  arma::cube XX_t_perm(K, K, n_sam);
  uvec o(n_sam, fill::zeros);
  arma::mat X_perm = X;
  arma::vec Yr_perm = Yr;

  SetSeed(init_seed);
  XX_t = CalculateXX(X);
  for(int n_perm=0; n_perm < N_perm; n_perm++){
    uvec o = randperm(n_sam);  // generate permuation
    Yr_perm = Yr(o);             // permute residual
    X_perm.col(1) = Yr_perm;    // set permuted design matrix
    XX_t_perm = CalculatePermX(XX_t, X, Yr_perm);
    List res =  Newton(freq_table, X_perm, XX_t_perm, W_init, weight, tol, iter_max, bias_correction, model_based_var, prop_presence, bias_correction_thresh);
    arma::mat res_W = res["W"];
    arma::vec res_Var = res["SVar"];
    BR_est_temp.row(n_perm) = res_W.row(1);
    VAR_est_temp.row(n_perm) = res_Var.t();
  }
  return List::create(Named("W") = BR_est_temp, Named("VAR") = VAR_est_temp);
}

// [[Rcpp::export]]
List PermutationAdjParallel(arma::mat freq_table, arma::vec Yr, arma::mat X,
                            arma::mat W_init, arma::mat weight,
                            double tol, int iter_max,
                            bool bias_correction, bool model_based_var,
                            arma::umat perm,
                            arma::vec prop_presence, double bias_correction_thresh)  {
  
  int n_otus = freq_table.n_cols;
  int n_sam  = freq_table.n_rows;
  int N_perm = perm.n_cols;
  int K = X.n_cols;
  
  arma::mat BR_est_temp(N_perm, n_otus); //save beta of trait information
  arma::mat VAR_est_temp(N_perm, n_otus); //save variance information
  arma::cube XX_t(K, K, n_sam);
  arma::cube XX_t_perm(K, K, n_sam);
  uvec o(n_sam, fill::zeros);
  arma::mat X_perm = X;
  arma::vec Yr_perm = Yr;
  
  XX_t = CalculateXX(X);
  for(int n_perm=0; n_perm < N_perm; n_perm++){
    uvec o = perm.col(n_perm);  // generate permuation
    Yr_perm = Yr(o);             // permute residual
    X_perm.col(1) = Yr_perm;    // set permuted design matrix
    XX_t_perm = CalculatePermX(XX_t, X, Yr_perm);
    List res =  Newton(freq_table, X_perm, XX_t_perm, W_init, weight, tol, iter_max, bias_correction, model_based_var, prop_presence, bias_correction_thresh);
    arma::mat res_W = res["W"];
    arma::vec res_Var = res["SVar"];
    BR_est_temp.row(n_perm) = res_W.row(1);
    VAR_est_temp.row(n_perm) = res_Var.t();
  }
  return List::create(Named("W") = BR_est_temp, Named("VAR") = VAR_est_temp);
}
