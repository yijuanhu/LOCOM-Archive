# -------------------------
# This script is used to compare six different methods: ANCOM; ALDEx2; WRENCH; DACOMP; Wilcox-Thres; Wilcox  
# Compared with last script: ANCOMBC is added. For ANCOM and ANCOMBC, both our filtering and their filtering criterion are applicable
# -------------------------
#library(ALDEx2)
#source("ancom_v2.1.R")
#library(phyloseq)
Method_Comparsion_Confounder <- function(otu_table, otu_table_sim, filter.idx, Y, C, C_name, fdr_target, method, 
                                         causal_otus_sim, n_otus_causal_sim, non_causal_otus_sim, n_otus_noncausal_sim,
                                         filter = "LOCOM"){
  
  # Args: otu_table: filtered otu_table
  #       otu_table_sim: original otu_table
  #       filter.idx: filder index
  #       Y: trait
  #       C: confounder
  #       C: confounder name
  #       fdr_tagert: fdr_target name
  #       method: method name
  #       filter: filtering criterion, "ANCOM": default criterion in ANCOM	  
  
  if(method == "ANCOMBC"){
    if(filter == "LOCOM"){
      #================Build a Phyloseq-Class Object from Scratch==================
      otu_mat <- t(otu_table_sim)
      rownames(otu_mat) = 1:nrow(otu_mat)
      colnames(otu_mat) = paste0("sample", 1:ncol(otu_mat))
      otu_mat <- otu_mat[-filter.idx, ]
      
      meta <- data.frame(group = Y, C, 
                         row.names = paste0("sample", 1:ncol(otu_mat)),
                         stringsAsFactors = FALSE)
      colnames(meta)[2:ncol(meta)] <- C_name
      
      tax_mat = matrix(sample(letters, 7 * nrow(otu_mat), replace = TRUE),nrow = nrow(otu_mat), ncol = 7)
      rownames(tax_mat) = rownames(otu_mat)
      colnames(tax_mat) = c("Kingdom", "Phylum", "Class", "Order","Family", "Genus", "Species")
      
      OTU = otu_table(otu_mat, taxa_are_rows = TRUE)
      META = sample_data(meta)
      TAX = tax_table(tax_mat)
      physeq = phyloseq(OTU, META, TAX)
      
      #========================Run ANCOMBC Using a Real Data=======================
      out = ancombc(phyloseq = physeq, formula = paste("group + ",  paste(C_name, collapse = " + "), sep = ""),
                     p_adj_method = "holm", zero_cut = 1, lib_cut = 0,
                     group = "group", 
                     struc_zero = TRUE, neg_lb = FALSE,
                     tol = 1e-5, max_iter = 100, conserve = TRUE,
                     alpha = 0.05, global = TRUE)  # here alpha level does not matter. we would use further check the detections using code below
      
    } else{
      #================Build a Phyloseq-Class Object from Scratch==================
      otu_mat <- t(otu_table_sim)
      rownames(otu_mat) = 1:nrow(otu_mat)
      colnames(otu_mat) = paste0("sample", 1:ncol(otu_mat))
      
      
      meta <- data.frame(group = Y, C, 
                         row.names = paste0("sample", 1:ncol(otu_mat)),
                         stringsAsFactors = FALSE)
      colnames(meta)[2:ncol(meta)] <- C_name
      
      tax_mat = matrix(sample(letters, 7 * nrow(otu_mat), replace = TRUE),nrow = nrow(otu_mat), ncol = 7)
      rownames(tax_mat) = rownames(otu_mat)
      colnames(tax_mat) = c("Kingdom", "Phylum", "Class", "Order","Family", "Genus", "Species")
      
      OTU = otu_table(otu_mat, taxa_are_rows = TRUE)
      META = sample_data(meta)
      TAX = tax_table(tax_mat)
      physeq = phyloseq(OTU, META, TAX)
      #========================Run ANCOMBC Using a Real Data=======================
      out = ancombc(phyloseq = physeq, formula = paste("group + ",  paste(C_name, collapse = " + "), sep = ""),
                    p_adj_method = "holm", zero_cut = 0.90, lib_cut = 1000,
                    group = "group", 
                    struc_zero = TRUE, neg_lb = FALSE,
                    tol = 1e-5, max_iter = 100, conserve = TRUE,
                    alpha = 0.05, global = TRUE)  # here alpha level does not matter. we would use further check the detections using code below
    }  
    #=========================Summarize Detection Results=======================
    otu.ancom = rownames(out$res$q_val[out$res$q_val[,1] <= fdr_target, ])
    (n_otu.ancom = length(otu.ancom))
    (sen.ancom = sum(otu.ancom %in% causal_otus_sim)/n_otus_causal_sim)
    (sep.ancom = 1- sum(otu.ancom %in% non_causal_otus_sim)/n_otus_noncausal_sim)
    (FDR.ancom = (n_otu.ancom - sum(otu.ancom %in% causal_otus_sim))/n_otu.ancom)
    
    n_otu <- n_otu.ancom
    sen <- sen.ancom
    sep <- sep.ancom	
    FDR <- FDR.ancom
  }
  
  if(method == "ANCOM"){
    if(filter == "LOCOM"){
      otu_table_sim_ancom <- t(otu_table_sim)
	  rownames(otu_table_sim_ancom) = 1:nrow(otu_table_sim_ancom)
      otu_table_sim_ancom <- otu_table_sim_ancom[-filter.idx, ]
      colnames(otu_table_sim_ancom) <- paste("ID", c(1:ncol(otu_table_sim_ancom)), sep = "")
      meta_data <- data.frame(Sample.ID = paste("ID", c(1:ncol(otu_table_sim_ancom)), sep = ""), Y = Y, C = C)    
      colnames(meta_data)[3:ncol(meta_data)] <- C_name
      
      feature_table = otu_table_sim_ancom; sample_var = "Sample.ID"; group_var = NULL
      out_cut = 0.05; zero_cut = 1; lib_cut = 0; neg_lb = FALSE
      prepro = feature_table_pre_process(feature_table, meta_data, sample_var, group_var, 
                                         out_cut, zero_cut, lib_cut, neg_lb)
    
    } else{
      otu_table_sim_ancom <- t(otu_table_sim)
	  rownames(otu_table_sim_ancom) = 1:nrow(otu_table_sim_ancom)
      colnames(otu_table_sim_ancom) <- paste("ID", c(1:ncol(otu_table_sim_ancom)), sep = "")
      meta_data <- data.frame(Sample.ID = paste("ID", c(1:ncol(otu_table_sim_ancom)), sep = ""), Y = Y, C = C)    
      colnames(meta_data)[3:ncol(meta_data)] <- C_name
      
      feature_table = otu_table_sim_ancom; sample_var = "Sample.ID"; group_var = NULL
      out_cut = 0.05; zero_cut = 0.90; lib_cut = 100; neg_lb = FALSE
      prepro = feature_table_pre_process(feature_table, meta_data, sample_var, group_var, 
                                         out_cut, zero_cut, lib_cut, neg_lb)
    }
    
    
    feature_table = prepro$feature_table 
    meta_data = prepro$meta_data # Preprocessed metadata
    struc_zero = prepro$structure_zeros # Structural zero info
    
    main_var = "Y"; p_adj_method = "BH";
    adj_formula = paste(C_name, collapse = " + "); rand_formula = NULL
    res.ancom = ANCOM(feature_table, meta_data, struc_zero, main_var, p_adj_method, 
                      fdr_target, adj_formula, rand_formula)
    
    otu.ancom = as.numeric(as.character(res.ancom$out$taxa_id[which(res.ancom$out$detected_0.9 == TRUE)])) # choose 0.9 percentile as cutoff
    (n_otu.ancom = length(otu.ancom))
    (sen.ancom = sum(otu.ancom %in% causal_otus_sim)/n_otus_causal_sim)
    (sep.ancom = 1- sum(otu.ancom %in% non_causal_otus_sim)/n_otus_noncausal_sim)
    (FDR.ancom = (n_otu.ancom - sum(otu.ancom %in% causal_otus_sim))/n_otu.ancom)
    
    n_otu <- n_otu.ancom
    sen <- sen.ancom
    sep <- sep.ancom	
    FDR <- FDR.ancom
  } 
  
  # -------------------
  # Method of ALDEx2
  # -------------------
  if(method == "ALDEx2") {
    otu_table_aldex2 <- t(otu_table)
    covariates <- data.frame("Y" = Y, C = C)
    colnames(covariates)[2:ncol(covariates)] <- C_name
    mm <- model.matrix( as.formula(paste(" ~ Y + ", paste(C_name, collapse = " + "), sep = "")), covariates)
    #x <- aldex.clr(otu_table_aldex2, mm, mc.samples=128, verbose=TRUE, denom="iqlr")
    x <- aldex.clr(otu_table_aldex2, mm, mc.samples=128, verbose=TRUE)
    x.tt <- aldex.glm(x)
    res.aldex2 <- data.frame(x.tt, stringsAsFactors=FALSE)  
    if (nrow(res.aldex2) == nrow(otu_table_sim)) {
      otu.aldex2 <- sort(which(res.aldex2$model.Y.Pr...t...BH <= fdr_target)) # can also use wi.eBH (Wilcox test p-value after BH)
    }else{
      #idx <- which(rowSums(otu_table_sim_aldex2) == 0)
      old.we.eBH <- res.aldex2$model.Y.Pr...t...BH
      for (idx.i in 1:length(filter.idx)) {
        temp.we.eBH <- old.we.eBH
        new.we.eBH <- insert(temp.we.eBH, filter.idx[idx.i], 100)
        old.we.eBH <- new.we.eBH
      }
      otu.aldex2 <- sort(which(new.we.eBH <= fdr_target))
    }
    
    (n_otu.aldex2 = length(otu.aldex2))
    (sen.aldex2 = sum(otu.aldex2 %in% causal_otus_sim)/n_otus_causal_sim)
    (sep.aldex2 = 1- sum(otu.aldex2 %in% non_causal_otus_sim)/n_otus_noncausal_sim)
    (FDR.aldex2 = (n_otu.aldex2 - sum(otu.aldex2 %in% causal_otus_sim))/n_otu.aldex2)
    
    n_otu <- n_otu.aldex2
    sen <- sen.aldex2
    sep <- sep.aldex2	
    FDR <- FDR.aldex2
  }
  
  return(list(n_otu = n_otu, sen = sen, sep = sep, FDR = FDR))
}


