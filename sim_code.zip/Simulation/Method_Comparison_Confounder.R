Method_Comparsion_Confounder <- function(otu.table, otu.table.sim, filter.idx, Y, C, C.name, fdr.target, method, 
                                         causal.otus.sim, n.otus.causal.sim, non.causal.otus.sim, n.otus.noncausal.sim,
                                         filter = "LOCOM"){
  
  # Args: otu.table: filtered otu.table
  #       otu.table.sim: original otu.table
  #       filter.idx: filder index
  #       Y: trait
  #       C: confounder
  #       C: confounder name
  #       fdr.tagert: fdr.target name
  #       method: method name
  #       filter: filtering criterion, "ANCOM": default criterion in ANCOM	  
  
  if(method == "ANCOMBC"){
      #================Build a Phyloseq-Class Object from Scratch==================
      otu.mat <- t(otu.table.sim)
      rownames(otu.mat) = 1:nrow(otu.mat)
      colnames(otu.mat) = paste0("sample", 1:ncol(otu.mat))
      #otu.mat <- otu.mat[-filter.idx, ]
      
      meta <- data.frame(group = Y, C, 
                         row.names = paste0("sample", 1:ncol(otu.mat)),
                         stringsAsFactors = FALSE)
      colnames(meta)[2:ncol(meta)] <- C.name
      
      tax_mat = matrix(sample(letters, 7 * nrow(otu.mat), replace = TRUE),nrow = nrow(otu.mat), ncol = 7)
      rownames(tax_mat) = rownames(otu.mat)
      colnames(tax_mat) = c("Kingdom", "Phylum", "Class", "Order","Family", "Genus", "Species")
      
      OTU = otu_table(otu.mat, taxa_are_rows = TRUE)
      META = sample_data(meta)
      TAX = tax_table(tax_mat)
      physeq = phyloseq(OTU, META, TAX)
      
      if(filter == "LOCOM"){
      #========================Run ANCOMBC Using a Real Data=======================
      out = ancombc(phyloseq = physeq, formula = paste("group + ",  paste(C.name, collapse = " + "), sep = ""),
                    p_adj_method = "holm", zero_cut = 0.80, lib_cut = 1000,
                    group = "group", 
                    struc_zero = TRUE, neg_lb = FALSE,
                    tol = 1e-5, max_iter = 100, conserve = TRUE,
                    alpha = 0.05, global = TRUE)  # here alpha level does not matter. we would use further check the detections using code below
     } else{
       #========================Run ANCOMBC Using a Real Data=======================
       out = ancombc(phyloseq = physeq, formula = paste("group + ",  paste(C.name, collapse = " + "), sep = ""),
                     p_adj_method = "holm", zero_cut = 0.90, lib_cut = 1000,
                     group = "group", 
                     struc_zero = TRUE, neg_lb = FALSE,
                     tol = 1e-5, max_iter = 100, conserve = TRUE,
                     alpha = 0.05, global = TRUE)  # here alpha level does not matter. we would use further check the detections using code below
    }  
    #=========================Summarize Detection Results=======================
    otu.ancom = rownames(out$res$q_val[out$res$q_val[,1] < fdr.target, ])
    (n.otu.ancom = length(otu.ancom))
    (sen.ancom = sum(otu.ancom %in% causal.otus.sim)/n.otus.causal.sim)
    (sep.ancom = 1- sum(otu.ancom %in% non.causal.otus.sim)/n.otus.noncausal.sim)
    (FDR.ancom = (n.otu.ancom - sum(otu.ancom %in% causal.otus.sim))/n.otu.ancom)
    
    n.otu <- n.otu.ancom
    sen <- sen.ancom
    sep <- sep.ancom	
    FDR <- FDR.ancom
  }
  
  if(method == "ANCOM"){
    
    otu.table.sim.ancom <- t(otu.table.sim)
    rownames(otu.table.sim.ancom) = 1:nrow(otu.table.sim.ancom)
    colnames(otu.table.sim.ancom) <- paste("ID", c(1:ncol(otu.table.sim.ancom)), sep = "")
    
    meta_data <- data.frame(Sample.ID = paste("ID", c(1:ncol(otu.table.sim.ancom)), sep = ""), Y = Y, C = C)    
    colnames(meta_data)[3:ncol(meta_data)] <- C.name
    feature_table = otu.table.sim.ancom; sample_var = "Sample.ID"; group_var = NULL
    out_cut = 0.05;  lib_cut = 0; neg_lb = FALSE
    if(filter == "LOCOM"){ 
      zero_cut = 0.80;
    } else {
      zero_cut = 0.90;
    }
    prepro = feature_table_pre_process(feature_table, meta_data, sample_var, group_var, 
                                       out_cut, zero_cut, lib_cut, neg_lb)
    feature_table = prepro$feature_table 
    meta_data = prepro$meta_data # Preprocessed metadata
    struc_zero = prepro$structure_zeros # Structural zero info
    
    main_var = "Y"; p_adj_method = "BH";
    adj_formula = paste(C.name, collapse = " + "); rand_formula = NULL
    res.ancom = ANCOM(feature_table, meta_data, struc_zero, main_var, p_adj_method, 
                      fdr.target, adj_formula, rand_formula)
    
    otu.ancom = as.numeric(as.character(res.ancom$out$taxa_id[which(res.ancom$out$detected_0.9 == TRUE)])) # choose 0.9 percentile as cutoff
    (n.otu.ancom = length(otu.ancom))
    (sen.ancom = sum(otu.ancom %in% causal.otus.sim)/n.otus.causal.sim)
    (sep.ancom = 1- sum(otu.ancom %in% non.causal.otus.sim)/n.otus.noncausal.sim)
    (FDR.ancom = (n.otu.ancom - sum(otu.ancom %in% causal.otus.sim))/n.otu.ancom)
    
    n.otu <- n.otu.ancom
    sen <- sen.ancom
    sep <- sep.ancom	
    FDR <- FDR.ancom
  } 
  
  # -------------------
  # Method of ALDEx2
  # -------------------
  if(method == "ALDEx2") {
    otu.table.aldex2 <- t(otu.table)
    covariates <- data.frame("Y" = Y, C = C)
    colnames(covariates)[2:ncol(covariates)] <- C.name
    mm <- model.matrix( as.formula(paste(" ~ Y + ", paste(C.name, collapse = " + "), sep = "")), covariates)
    x <- aldex.clr(otu.table.aldex2, mm, mc.samples=128, verbose=TRUE)
    x.tt <- aldex.glm(x)
    res.aldex2 <- data.frame(x.tt, stringsAsFactors=FALSE)  
    if (nrow(res.aldex2) == nrow(otu.table.sim)) {
      otu.aldex2 <- sort(which(res.aldex2$model.Y.Pr...t...BH < fdr.target)) # can also use wi.eBH (Wilcox test p-value after BH)
    }else{
      old.we.eBH <- res.aldex2$model.Y.Pr...t...BH
      for (idx.i in 1:length(filter.idx)) {
        temp.we.eBH <- old.we.eBH
        new.we.eBH <- insert(temp.we.eBH, filter.idx[idx.i], 100)
        old.we.eBH <- new.we.eBH
      }
      otu.aldex2 <- sort(which(new.we.eBH < fdr.target))
    }
    
    (n.otu.aldex2 = length(otu.aldex2))
    (sen.aldex2 = sum(otu.aldex2 %in% causal.otus.sim)/n.otus.causal.sim)
    (sep.aldex2 = 1- sum(otu.aldex2 %in% non.causal.otus.sim)/n.otus.noncausal.sim)
    (FDR.aldex2 = (n.otu.aldex2 - sum(otu.aldex2 %in% causal.otus.sim))/n.otu.aldex2)
    
    n.otu <- n.otu.aldex2
    sen <- sen.aldex2
    sep <- sep.aldex2	
    FDR <- FDR.aldex2
  }
  
  return(list(n.otu = n.otu, sen = sen, sep = sep, FDR = FDR))
}


