# ----------------------------
# Binary Trait & Binary Confounder Setting Simulation
# ----------------------------
library(dirmult)
library(Rcpp)
library(RcppArmadillo)
library(R.utils)
library(metap)
library(permute)
library(parallel)
source("utils.R")
source("LOCOM_fun.R")
sourceCpp("LOCOM.cpp")

causal.type <- 1    # simulation scenario
library.mu <- 10000 # mean of library size
disp <- 0.02        # dispersion parameter
n.sam <- 100        # total sample size
alpha <- 5          # effect size 
gamma <- 2          # confounder effect size
freq.thres <- 0     # frequency threshold
censor.thres <- 0.8 # presence/absence threshold
ss <- 3             
library.sd = library.mu/ss # standard error in library size 
lib.sizer.lower = 2000     # lower bound for library size
fdr.target <- 0.2 # nominal fdr value

n.sim <- 5
otumat <- array(0, dim = c(n.sim, 5))
p.global.mat <- rep(0, n.sim)
for (i.seed in 1:n.sim) {
  cat("i.seed",i.seed,"\n")

  # ----------------------------
  # Set frequency value
  # ----------------------------
  pi <- read.table("input_throat/fit_dirmult_pi.txt", header=FALSE, as.is=TRUE)[,1]
  n.otus = length(pi)
  
  if(causal.type == 1){
	  spike.col.only <- which(pi >= 0.002)[1:10]
	  confounder.col.only <- which(pi >= 0.002)[21:30]
	  spike.confounder.both <- which(pi >= 0.002)[11:20]
  } 
  
  if(causal.type == 2){
  	spike.col.only <- order(pi, decreasing = TRUE)[1:3]
	  confounder.col.only <- order(pi, decreasing = TRUE)[31:33]
	  spike.confounder.both <- order(pi, decreasing = TRUE)[4:5]
  }
  
  causal.otus.sim = c(spike.col.only, spike.confounder.both)
  n.otus.causal.sim = length(causal.otus.sim)
  non.causal.otus.sim = setdiff(1:n.otus, causal.otus.sim)
  n.otus.noncausal.sim = length(non.causal.otus.sim)
  
  # -----------------------------
  # Simulate Data
  # -----------------------------
  # simData <- SimulateData(otu.freq = pi, 
  #                         spike.col.only = spike.col.only, 
  #                         confounder.col.only = confounder.col.only, 
  #                         spike.confounder.both = spike.confounder.both, 
  #                         alpha = alpha, 
  #                         gamma = gamma, 
  #                         library.mu = library.mu, 
  #                         library.sd = library.sd, 
  #                         lib.sizer.lower = lib.sizer.lower, 
  #                         disp = disp, 
  #                         n.sam = n.sam, 
  #                         trait = "BinBin",
  #                         frac = 0.5, 
  #                         rho = 0.2, 
  #                         causal.type = causal.type,
  #                         seed = i.seed)
  
  # simData <- SimulateData(otu.freq = pi, 
  #                         spike.col.only = spike.col.only, 
  #                         confounder.col.only = confounder.col.only, 
  #                         spike.confounder.both = spike.confounder.both, 
  #                         alpha = alpha, 
  #                         gamma = gamma, 
  #                         library.mu = library.mu, 
  #                         library.sd = library.sd, 
  #                         lib.sizer.lower = lib.sizer.lower, 
  #                         disp = disp, 
  #                         n.sam = n.sam, 
  #                         trait = "BinCont",
  #                         frac = 0.5, 
  #                         rho = 0.2, 
  #                         causal.type = causal.type,
  #                         seed = i.seed)
  
  # simData <- SimulateData(otu.freq = pi,
  #                         spike.col.only = spike.col.only,
  #                         confounder.col.only = confounder.col.only,
  #                         spike.confounder.both = spike.confounder.both,
  #                         alpha = alpha,
  #                         gamma = gamma,
  #                         library.mu = library.mu,
  #                         library.sd = library.sd,
  #                         lib.sizer.lower = lib.sizer.lower,
  #                         disp = disp,
  #                         n.sam = n.sam,
  #                         trait = "ContBin",
  #                         frac = 0.5,
  #                         rho = 0.2,
  #                         causal.type = causal.type,
  #                         seed = i.seed)
 
  simData <- SimulateData(otu.freq = pi,
                          spike.col.only = spike.col.only,
                          confounder.col.only = confounder.col.only,
                          spike.confounder.both = spike.confounder.both,
                          alpha = alpha,
                          gamma = gamma,
                          library.mu = library.mu,
                          library.sd = library.sd,
                          lib.sizer.lower = lib.sizer.lower,
                          disp = disp,
                          n.sam = n.sam,
                          trait = "ContCont",
                          frac = 0.5,
                          rho = 0.5,
                          causal.type = causal.type,
                          seed = i.seed)

  otu.table.sim <- simData$otu.table.sim
  freq.table.sim <- simData$freq.table.sim
  Y <- simData$Y
  C <- simData$C
  
  # -----------------------------
  # Filter Data
  # -----------------------------
  colnames(otu.table.sim) <- c(1:ncol(otu.table.sim))
  filterData <- filterOTU(otu.table = otu.table.sim, freq.table = freq.table.sim, refer.col = 468, censor.thres = censor.thres, freq.thres = freq.thres, eps = 1)
  otu.table.sim.filter <-filterData$otu.table.filter
  refer.col <- filterData$refer.col
  otuname <- filterData$otuname
  filter.idx <- filterData$filter.idx
  censoring.rate <- filterData$censoring.rate
  causal.otus.sim.filter <- causal.otus.sim[!causal.otus.sim %in% filter.idx]
  non.causal.otus.sim.filter <- non.causal.otus.sim[!non.causal.otus.sim %in% filter.idx]
  cat("number of causal otu:", length(causal.otus.sim.filter), "\n") 
  
  # ------------------------------
  # Fit LOCOM
  # ------------------------------
  res <- locom(otu.table = otu.table.sim.filter, Y = Y, C = C,
               ref.otu = refer.col,
               fdr.nominal = fdr.target, seed = NULL,
               n.perm.max = 50000, n.rej.stop = 100, n.cores = 1)			   
  
  
  p.global.mat <- res$p.global
  res.summary <- summarize_otu_results(otuname = colnames(otu.table.sim.filter),
                                       qvalue = res$q.otu,
                                       causal.otus = causal.otus.sim.filter,
                                       non.causal.otus  = non.causal.otus.sim.filter,
                                       fdr.target = fdr.target)
  
  n.otu <-  res.summary$n.otu
  sen.otu <-  res.summary$sen
  sep.otu <-  res.summary$sep
  fdr.otu <-  res.summary$fdr
  include <- as.numeric(468 %in% res.summary$otu.detected) #whether reference otu is included or not
  
  otumat[i.seed, ] <- c(n.otu, sen.otu, sep.otu, fdr.otu, include)
  p.global.mat[i.seed] <- res$p.global
}
